"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var item_service_1 = require("../../item/item.service");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("nativescript-angular/router");
var router_2 = require("@angular/router");
var location_service_1 = require("../../shared/location/location.service");
var nativescript_google_maps_sdk_1 = require("nativescript-google-maps-sdk");
var element_registry_1 = require("nativescript-angular/element-registry");
var nativescript_ui_calendar_1 = require("nativescript-ui-calendar");
var angular_1 = require("nativescript-ui-calendar/angular");
var calendarModule = require("nativescript-ui-calendar");
var color_1 = require("tns-core-modules/color");
var TNSPhone = require("nativescript-phone");
element_registry_1.registerElement('MapView', function () { return nativescript_google_maps_sdk_1.MapView; });
var EstilosEvtComponent = /** @class */ (function () {
    function EstilosEvtComponent(itemService, userService, locationService, routerExtensions, route) {
        this.itemService = itemService;
        this.userService = userService;
        this.locationService = locationService;
        this.routerExtensions = routerExtensions;
        this.route = route;
        this.location = { latitude: 0, longitude: 0, altitude: 0 };
        this.currentlocation = { latitude: 0, longitude: 0, altitude: 0 };
        this.pagenumber = 0;
        this.isLoading = false;
        this.showcalendar = false;
        this.showwebview = false;
        this.showmap = false;
        this.eventos = [];
        this.curevento = null;
        this.zoom = 15;
        this.minZoom = 0;
        this.maxZoom = 40;
        this.bearing = 0;
        this.tilt = 0;
        this.padding = [40, 40, 40, 40];
        this._events = new Array();
        this.cureventindex = -1;
        var id = this.route.snapshot.params["idcategoria"];
        this.tipo = this.route.snapshot.params["tipo"];
        this.item = this.itemService.getItem(id);
        this.item.menu = [];
        this.loadlist(this.item.menu, "estilosevt", "-1");
        this._monthViewStyle = this.getMonthViewStyle();
        this._eventsViewMode = calendarModule.CalendarEventsViewMode.Inline;
        this.eventos.push({
            row: { nome: '', descricao: '' }
        });
        this.curevento = this.eventos[0];
        this._viewMode = calendarModule.CalendarViewMode.Month;
    }
    ;
    Object.defineProperty(EstilosEvtComponent.prototype, "viewMode", {
        get: function () {
            return this._viewMode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(EstilosEvtComponent.prototype, "eventSource", {
        get: function () {
            return this._events;
        },
        enumerable: true,
        configurable: true
    });
    EstilosEvtComponent.prototype.ligafone = function () {
        TNSPhone.dial(this.curevento.row.fone, false);
    };
    EstilosEvtComponent.prototype.showCalendar = function () {
        this.showcalendar = !this.showcalendar;
    };
    EstilosEvtComponent.prototype.goToCurrentDay = function () {
        var date = new Date();
        this._calendar.nativeElement.goToDate(date);
    };
    EstilosEvtComponent.prototype.prevevt = function () {
        if (this.cureventindex > 0)
            this.cureventindex--;
        else
            this.cureventindex = this._events.length - 1;
        this._calendar.nativeElement.goToDate(this._events[this.cureventindex].startDate);
    };
    EstilosEvtComponent.prototype.nextevt = function () {
        this.cureventindex = ((this.cureventindex + 1) % this._events.length);
        this._calendar.nativeElement.goToDate(this._events[this.cureventindex].startDate);
    };
    EstilosEvtComponent.prototype.getMonthViewStyle = function () {
        var monthViewStyle = new calendarModule.CalendarMonthViewStyle();
        /*monthViewStyle.backgroundColor = "Gray";
        monthViewStyle.showTitle = true;
        monthViewStyle.showWeekNumbers = false;
        monthViewStyle.showDayNames = true;
    
        const todayCellStyle = new DayCellStyle();
        todayCellStyle.cellBackgroundColor = "#66bbae";
        todayCellStyle.cellBorderWidth = 2;
        todayCellStyle.cellBorderColor = "#f1e8ca";
        todayCellStyle.cellTextColor = "#5b391e";
        todayCellStyle.cellTextFontName = "Times New Roman";
        todayCellStyle.cellTextFontStyle = "Bold";
        todayCellStyle.cellTextSize = 14;
        monthViewStyle.todayCellStyle = todayCellStyle;
    
        const dayCellStyle = new DayCellStyle();
        dayCellStyle.showEventsText = false;
        dayCellStyle.eventTextColor = "White";
        dayCellStyle.eventFontName = "Times New Roman";
        dayCellStyle.eventFontStyle = "BoldItalic";
        dayCellStyle.eventTextSize = 8;
        dayCellStyle.cellAlignment = "Top";
        dayCellStyle.cellPaddingHorizontal = 10;
        dayCellStyle.cellPaddingVertical = 5;
        dayCellStyle.cellBackgroundColor = "#ffffff";
        dayCellStyle.cellBorderWidth = 1;
        dayCellStyle.cellBorderColor = "#f1e8ca";
        dayCellStyle.cellTextColor = "#745151";
        dayCellStyle.cellTextFontName = "Times New Roman";
        dayCellStyle.cellTextFontStyle = "Bold";
        dayCellStyle.cellTextSize = 10;
        monthViewStyle.dayCellStyle = dayCellStyle;
    
        const weekendCellStyle = new DayCellStyle();
        weekendCellStyle.eventTextColor = "BlueViolet";
        weekendCellStyle.eventFontName = "Times New Roman";
        weekendCellStyle.eventFontStyle = "BoldItalic";
        weekendCellStyle.eventTextSize = 8;
        weekendCellStyle.cellAlignment = "Top";
        weekendCellStyle.cellPaddingHorizontal = 10;
        weekendCellStyle.cellPaddingVertical = 5;
        weekendCellStyle.cellBackgroundColor = "Gray";
        weekendCellStyle.cellBorderWidth = 1;
        weekendCellStyle.cellBorderColor = "#f1e8ca";
        weekendCellStyle.cellTextColor = "#745151";
        weekendCellStyle.cellTextFontName = "Times New Roman";
        weekendCellStyle.cellTextFontStyle = "Bold";
        weekendCellStyle.cellTextSize = 12;
        monthViewStyle.weekendCellStyle = weekendCellStyle;
    
        const selectedCellStyle = new DayCellStyle();
        selectedCellStyle.eventTextColor = "Blue";
        selectedCellStyle.eventFontName = "Times New Roman";
        selectedCellStyle.eventFontStyle = "Bold";
        selectedCellStyle.eventTextSize = 8;
        selectedCellStyle.cellAlignment = "Top";
        selectedCellStyle.cellPaddingHorizontal = 10;
        selectedCellStyle.cellPaddingVertical = 5;
        selectedCellStyle.cellBackgroundColor = "#dbcbbb";
        selectedCellStyle.cellBorderWidth = 2;
        selectedCellStyle.cellBorderColor = "#745151";
        selectedCellStyle.cellTextColor = "Black";
        selectedCellStyle.cellTextFontName = "Times New Roman";
        selectedCellStyle.cellTextFontStyle = "Bold";
        selectedCellStyle.cellTextSize = 18;
        monthViewStyle.selectedDayCellStyle = selectedCellStyle;
    
        const dayNameCellStyle = new CellStyle();
        dayNameCellStyle.cellBackgroundColor = "#f1e8ca";
        dayNameCellStyle.cellBorderWidth = 1;
        dayNameCellStyle.cellBorderColor = "#745151";
        dayNameCellStyle.cellTextColor = "#745151";
        dayNameCellStyle.cellTextFontName = "Times New Roman";
        dayNameCellStyle.cellTextFontStyle = "Bold";
        dayNameCellStyle.cellTextSize = 10;
        monthViewStyle.dayNameCellStyle = dayNameCellStyle;
    
        const titleCellStyle = new DayCellStyle();
        titleCellStyle.cellBackgroundColor = "#bbcbdb";
        titleCellStyle.cellBorderWidth = 1;
        titleCellStyle.cellBorderColor = "#745151";
        titleCellStyle.cellTextColor = "#dd855c";
        titleCellStyle.cellTextFontName = "Times New Roman";
        titleCellStyle.cellTextFontStyle = "Bold";
        titleCellStyle.cellTextSize = 18;
        monthViewStyle.titleCellStyle = titleCellStyle;
    */
        return monthViewStyle;
    };
    Object.defineProperty(EstilosEvtComponent.prototype, "monthViewStyle", {
        get: function () {
            return this._monthViewStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(EstilosEvtComponent.prototype, "eventsViewMode", {
        get: function () {
            return this._eventsViewMode;
        },
        enumerable: true,
        configurable: true
    });
    EstilosEvtComponent.prototype.tapevento = function (args) {
        var calendar = args.object;
        console.dir(args.eventData);
        var s = args.eventData.title.split(/[:]/);
        for (var i = 0; i < this.eventos.length; i++) {
            if (this.eventos[i].row.id == s[1]) {
                this.cureventindex = i;
                break;
            }
        }
        this.eventoclick(this.eventos[this.cureventindex]);
    };
    EstilosEvtComponent.prototype.onDateSelected = function (args) {
        var calendar = args.object;
        var date = args.date;
        var events = calendar.getEventsForDate(date);
    };
    EstilosEvtComponent.prototype.configureevento = function (item) {
        var t = item.row.datahorario.split(/[- :]/);
        var data = new Date(Date.UTC(t[0], t[1] - 1, t[2], t[3], t[4], t[5]));
        t = item.row.datafim.split(/[- :]/);
        var datafim = new Date(Date.UTC(t[0], t[1] - 1, t[2], t[3], t[4], t[5]));
        var semana = ["Domingo", "Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira", "Sábado"];
        var meses = ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"];
        var abrevsem = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SAB"];
        var diames = data.getUTCDate() < 10 ? "0" + data.getUTCDate() : data.getUTCDate();
        var mes = data.getUTCMonth() < 9 ? "0" + (data.getUTCMonth() + 1) : (data.getUTCMonth() + 1);
        var hora = data.getUTCHours() < 10 ? "0" + data.getUTCHours() : data.getUTCHours();
        var minutos = data.getUTCMinutes() < 10 ? "0" + data.getUTCMinutes() : data.getUTCMinutes();
        var horafim = datafim.getUTCHours() < 10 ? "0" + datafim.getUTCHours() : datafim.getUTCHours();
        var minutosfim = datafim.getUTCMinutes() < 10 ? "0" + datafim.getUTCMinutes() : datafim.getUTCMinutes();
        item.row.data = diames + "\\" + mes + "\\" + data.getUTCFullYear() + " - " + semana[data.getDay()];
        item.row.time = hora + ":" + minutos;
        item.row.timefim = horafim + ":" + minutosfim;
        item.row.abrevmes = meses[data.getUTCMonth()];
        item.row.abrevsem = abrevsem[data.getDay()];
        item.row.diames = diames;
    };
    EstilosEvtComponent.prototype.webViewTouch = function (event) {
    };
    EstilosEvtComponent.prototype.webViewPan = function (event) {
    };
    EstilosEvtComponent.prototype.loadlist = function (array, key, idestilo) {
        var _this = this;
        this.isLoading = true;
        this.userService.db
            .get(encodeURI("key=" + key +
            "&idcategoria=" + this.route.snapshot.params["idcategoria"] +
            "&cidade=" + this.route.snapshot.params["cidade"] +
            "&uf=" + this.route.snapshot.params["uf"] +
            "&idestilo=" + idestilo))
            .subscribe(function (res) {
            if (res != null) {
                if (key == "estilosevt") {
                    var row = {
                        id: "-1",
                        nome: "TODOS",
                        idcategoria: "1"
                    };
                    _this.item.menu.push({
                        row: row,
                        toString: function () { return row.nome; },
                    });
                }
                var i = 0;
                _this.cureventindex = -1;
                _this.goToCurrentDay();
                _this._calendar.nativeElement.reload();
                _this._calendar.nativeElement.selectedDate = new Date();
                _this._events = new Array();
                res.result.forEach(function (row) {
                    array.push({
                        row: row,
                        toString: function () { return row.nome; },
                    });
                    if (key == "eventosregiao") {
                        var startDate = void 0, endDate = void 0, event_1;
                        var t = row.datahorario.split(/[- :]/);
                        console.log("hora=" + t[3]);
                        startDate = new Date(row.datahorario);
                        console.log(startDate.toString());
                        console.log((new Date()).toUTCString());
                        endDate = new Date(row.datafim);
                        var colors = [new color_1.Color(200, 188, 26, 214), new color_1.Color(220, 255, 109, 130), new color_1.Color(255, 55, 45, 255), new color_1.Color(199, 17, 227, 10), new color_1.Color(255, 255, 54, 3)];
                        event_1 = new nativescript_ui_calendar_1.CalendarEvent(row.nome + ":" + row.id, startDate, endDate, false, colors[(i++) * 10 % (colors.length - 1)]);
                        _this._events.push(event_1);
                        _this.configureevento(array[array.length - 1]);
                    }
                });
                if (key == "eventosregiao") {
                    _this.cureventindex = 0;
                    _this._calendar.nativeElement.goToDate(_this._events[_this.cureventindex].startDate);
                }
                console.dir(array);
            }
            _this.isLoading = false;
        });
    };
    EstilosEvtComponent.prototype.gotocurday = function () {
        this._calendar.nativeElement.goToDate(new Date());
    };
    EstilosEvtComponent.prototype.goback = function () {
        if (this.showwebview)
            this.showwebview = false;
        else if (this.showmap)
            this.showmap = false;
        else if (this.pagenumber == 0)
            this.routerExtensions.backToPreviousPage();
        else
            this.pagenumber--;
    };
    EstilosEvtComponent.prototype.abresite = function () {
        var webview = this.webViewRef.nativeElement;
        webview.src = this.curevento.row.site;
        this.showwebview = true;
    };
    EstilosEvtComponent.prototype.onMarkerEvent = function (args) {
        console.log("Marker Event: '" + args.eventName
            + "' triggered on: " + args.marker.title
            + ", Lat: " + args.marker.position.latitude + ", Lon: " + args.marker.position.longitude, args);
    };
    EstilosEvtComponent.prototype.onMapReady = function (event) {
        console.log('Map Ready');
        this.mapView = event.object;
    };
    EstilosEvtComponent.prototype.onCoordinateTapped = function (args) {
        console.log("Coordinate Tapped, Lat: " + args.position.latitude + ", Lon: " + args.position.longitude, args);
    };
    EstilosEvtComponent.prototype.onCameraChanged = function (args) {
        console.log("Camera changed: " + JSON.stringify(args.camera), JSON.stringify(args.camera) === this.lastCamera);
        this.lastCamera = JSON.stringify(args.camera);
    };
    EstilosEvtComponent.prototype.abremapa = function () {
        var _this = this;
        this.locationService.getlatlongFromEnd(this.curevento.row)
            .subscribe(function (res) {
            _this.locationService.getLocationOnce()
                .then(function (location) {
                console.log("Location received: ");
                console.dir(location);
                _this.currentlocation.latitude = location.latitude;
                _this.currentlocation.longitude = location.longitude;
                console.dir(res);
                _this.location.latitude = res.results[0].geometry.location.lat; //location.latitude;// (<any>res).results[0].geometry.location.lat;
                _this.location.longitude = res.results[0].geometry.location.lng; //location.longitude;//(<any>res).results[0].geometry.location.lng;
                _this.location.altitude = 0;
                var marker = new nativescript_google_maps_sdk_1.Marker();
                marker.position = nativescript_google_maps_sdk_1.Position.positionFromLatLng(_this.location.latitude, _this.location.longitude);
                marker.title = _this.curevento.row.nomelocal;
                marker.snippet = _this.curevento.row.nome;
                marker.userData = { index: 0 };
                marker.visible = true;
                _this.mapView.addMarker(marker);
                marker = new nativescript_google_maps_sdk_1.Marker();
                marker.position = nativescript_google_maps_sdk_1.Position.positionFromLatLng(_this.currentlocation.latitude, _this.currentlocation.longitude);
                marker.title = "EU";
                marker.snippet = "bora lá";
                marker.userData = { index: 1 };
                marker.visible = true;
                _this.mapView.addMarker(marker);
                marker = _this.mapView.findMarker(function (marker) {
                    return marker.userData.index === 1;
                });
                console.log("Moving marker...", marker.userData);
                var __this = _this;
                _this.locationService.startwatch(__this, marker);
                _this.mapView.myLocationEnabled = true;
                _this.mapView.settings.zoomControlsEnabled = true;
                _this.mapView.settings.compassEnabled = true;
                _this.mapView.settings.indoorLevelPickerEnabled = true;
                _this.mapView.settings.mapToolbarEnabled = true;
                _this.mapView.settings.myLocationButtonEnabled = true;
                _this.mapView.settings.rotateGesturesEnabled = true;
                _this.mapView.settings.scrollGesturesEnabled = true;
                _this.mapView.settings.tiltGesturesEnabled = true;
                _this.mapView.settings.zoomGesturesEnabled = true;
                //***  setViewport não funciona
                /*var southwest=Position.positionFromLatLng(this.startpointLatitude,this.startpointLongitude),
                 northeast=Position.positionFromLatLng(this.latitude,this.longitude);
                 let tmplat=southwest.latitude;
                 southwest.latitude=Math.min(southwest.latitude,northeast.latitude);
                 northeast.latitude=Math.max(tmplat,northeast.latitude);
                 tmplat=southwest.longitude;
                 southwest.longitude=Math.max(southwest.longitude,northeast.longitude);
                 northeast.longitude=Math.min(tmplat,northeast.longitude);
    
                 let viewport = {
                  southwest: {
                      latitude: southwest.latitude + 0.001,
                      longitude: northeast.longitude + 0.001
                  },
                  northeast: {
                      latitude: northeast.latitude - 0.001,
                      longitude: southwest.longitude - 0.001
                  }
              }
    
                var bounds=Bounds.fromCoordinates(
                  Position.positionFromLatLng(viewport.southwest.latitude,viewport.southwest.longitude),
                  Position.positionFromLatLng(viewport.northeast.latitude,viewport.northeast.longitude)
                );*/
                // this.mapView.setViewport(bounds, 100);
                //console.dir(bounds.southwest.latitude);
                _this.showmap = true;
            }).catch(function (error) {
                console.log("Location error received: " + error);
                alert("Location error received: " + error);
            });
        });
    };
    EstilosEvtComponent.prototype.onclick = function (item) {
        // this.routerExtensions.navigate(["/item/"+item.id], { clearHistory: false });
        //this.curevento=[];
        this.curevento = null;
        this.eventos = [];
        this.loadlist(this.eventos, "eventosregiao", item.row.id.toString());
        console.dir(item);
        this.pagenumber++;
    };
    EstilosEvtComponent.prototype.eventoclick = function (item) {
        this.curevento = item;
        this.pagenumber++;
        console.dir(this.curevento);
    };
    EstilosEvtComponent.prototype.onSwipe = function (args) {
        console.log("Swipe!");
        console.log("Object that triggered the event: " + args.object);
        console.log("View that triggered the event: " + args.view);
        console.log("Event name: " + args.eventName);
        console.log("Swipe Direction: " + args.direction);
        switch (args.direction) {
            case 1:
                if (this.pagenumber == 0)
                    this.goback();
                else if (this.pagenumber > 1)
                    this.pagenumber--;
                else if (this.pagenumber == 1) {
                    this.pagenumber--;
                }
                break;
            case 2:
                if (this.pagenumber == 1) {
                    if (this.curevento != null)
                        this.pagenumber++;
                }
                break;
        }
        /* console.log("Pan!");
             console.log("Object that triggered the event: " + args.object);
             console.log("View that triggered the event: " + args.view);
             console.log("Event name: " + args.eventName);
             console.log("Pan delta: [" + args.deltaX + ", " + args.deltaY + "] state: " + args.state);
     
             this.deltaX = args.deltaX;
             this.deltaY = args.deltaY;
             this.state = args.state;
         this.direction = args.direction;*/
    };
    EstilosEvtComponent.prototype.ngOnInit = function () {
        //this.item = this.itemService.getItem();
        //console.log("items");
        //console.dir(this.items);
    };
    __decorate([
        core_1.ViewChild("myWebView"),
        __metadata("design:type", core_1.ElementRef)
    ], EstilosEvtComponent.prototype, "webViewRef", void 0);
    __decorate([
        core_1.ViewChild("myCalendar"),
        __metadata("design:type", angular_1.RadCalendarComponent)
    ], EstilosEvtComponent.prototype, "_calendar", void 0);
    EstilosEvtComponent = __decorate([
        core_1.Component({
            selector: "ns-estilosevt",
            moduleId: module.id,
            templateUrl: "./estilosevt.component.html",
        }),
        __metadata("design:paramtypes", [item_service_1.ItemService,
            user_service_1.UserService,
            location_service_1.LocationService,
            router_1.RouterExtensions,
            router_2.ActivatedRoute])
    ], EstilosEvtComponent);
    return EstilosEvtComponent;
}());
exports.EstilosEvtComponent = EstilosEvtComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXN0aWxvc2V2dC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJlc3RpbG9zZXZ0LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5RTtBQUV6RSx3REFBc0Q7QUFDdEQsK0RBQTZEO0FBQzdELHNEQUErRDtBQUMvRCwwQ0FBaUQ7QUFFakQsMkVBQXVGO0FBQ3ZGLDZFQUFpRjtBQUVqRiwwRUFBd0U7QUFDeEUscUVBQWtHO0FBQ2xHLDREQUF3RTtBQUN4RSx5REFBMkQ7QUFDM0QsZ0RBQStDO0FBQy9DLDZDQUErQztBQUUvQyxrQ0FBZSxDQUFDLFNBQVMsRUFBRSxjQUFNLE9BQUEsc0NBQU8sRUFBUCxDQUFPLENBQUMsQ0FBQztBQU8xQztJQTRCRSw2QkFBb0IsV0FBd0IsRUFDbEMsV0FBd0IsRUFDeEIsZUFBZ0MsRUFDaEMsZ0JBQWtDLEVBQ2xDLEtBQXFCO1FBSlgsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFDbEMsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFDeEIsb0JBQWUsR0FBZixlQUFlLENBQWlCO1FBQ2hDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsVUFBSyxHQUFMLEtBQUssQ0FBZ0I7UUE3Qi9CLGFBQVEsR0FBaUIsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDO1FBQ3BFLG9CQUFlLEdBQWlCLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUMzRSxlQUFVLEdBQVcsQ0FBQyxDQUFDO1FBRXZCLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFDM0IsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFDN0IsWUFBTyxHQUFZLEtBQUssQ0FBQztRQUdsQixZQUFPLEdBQVUsRUFBRSxDQUFDO1FBQzNCLGNBQVMsR0FBUSxJQUFJLENBQUM7UUFFdEIsU0FBSSxHQUFHLEVBQUUsQ0FBQztRQUNWLFlBQU8sR0FBRyxDQUFDLENBQUM7UUFDWixZQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2IsWUFBTyxHQUFHLENBQUMsQ0FBQztRQUNaLFNBQUksR0FBRyxDQUFDLENBQUM7UUFDVCxZQUFPLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUVwQixZQUFPLEdBQXlCLElBQUksS0FBSyxFQUFpQixDQUFDO1FBQ2xFLGtCQUFhLEdBQVcsQ0FBQyxDQUFDLENBQUM7UUFTekIsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2xELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDaEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDO1FBQ3BFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO1lBQ2hCLEdBQUcsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtTQUNqQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0lBQ3pELENBQUM7SUF0QmlFLENBQUM7SUF3Qm5FLHNCQUFJLHlDQUFRO2FBQVo7WUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUN4QixDQUFDOzs7T0FBQTtJQUVELHNCQUFJLDRDQUFXO2FBQWY7WUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN0QixDQUFDOzs7T0FBQTtJQUVELHNDQUFRLEdBQVI7UUFDRSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsMENBQVksR0FBWjtRQUNFLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFBO0lBQ3hDLENBQUM7SUFFRCw0Q0FBYyxHQUFkO1FBQ0UsSUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELHFDQUFPLEdBQVA7UUFDRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztZQUN6QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkIsSUFBSTtZQUNGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtJQUNuRixDQUFDO0lBRUQscUNBQU8sR0FBUDtRQUNFLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNyRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUE7SUFFbkYsQ0FBQztJQUVELCtDQUFpQixHQUFqQjtRQUNFLElBQU0sY0FBYyxHQUFHLElBQUksY0FBYyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O01Bc0ZGO1FBQ0UsTUFBTSxDQUFDLGNBQWMsQ0FBQztJQUN4QixDQUFDO0lBRUQsc0JBQUksK0NBQWM7YUFBbEI7WUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUVELHNCQUFJLCtDQUFjO2FBQWxCO1lBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDOUIsQ0FBQzs7O09BQUE7SUFFTSx1Q0FBUyxHQUFoQixVQUFpQixJQUFvRDtRQUNuRSxJQUFNLFFBQVEsR0FBNkIsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUV2RCxPQUFPLENBQUMsR0FBRyxDQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDekMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQzdDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztnQkFDdkIsS0FBSyxDQUFDO1lBQ1IsQ0FBQztRQUVILENBQUM7UUFFRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUE7SUFDcEQsQ0FBQztJQUdELDRDQUFjLEdBQWQsVUFBZSxJQUFnQztRQUM3QyxJQUFNLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMxQyxJQUFNLElBQUksR0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzdCLElBQU0sTUFBTSxHQUF5QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVELDZDQUFlLEdBQWYsVUFBZ0IsSUFBSTtRQUNsQixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDNUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pFLElBQUksTUFBTSxHQUFHLENBQUMsU0FBUyxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDbEgsSUFBSSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pHLElBQUksUUFBUSxHQUFHLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDaEUsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xGLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDN0YsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25GLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM1RixJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBVyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDL0YsSUFBSSxVQUFVLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRXhHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNuRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQztRQUNyQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxPQUFPLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQztRQUM5QyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDOUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztJQUMzQixDQUFDO0lBRUQsMENBQVksR0FBWixVQUFhLEtBQUs7SUFFbEIsQ0FBQztJQUVELHdDQUFVLEdBQVYsVUFBVyxLQUFLO0lBRWhCLENBQUM7SUFFRCxzQ0FBUSxHQUFSLFVBQVMsS0FBSyxFQUFFLEdBQUcsRUFBRSxRQUFRO1FBQTdCLGlCQThEQztRQTdEQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7YUFDaEIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsR0FBRztZQUN6QixlQUFlLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztZQUMzRCxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNqRCxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztZQUN6QyxZQUFZLEdBQUcsUUFBUSxDQUFDLENBQUM7YUFDMUIsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNoQixFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFDeEIsSUFBSSxHQUFHLEdBQVE7d0JBQ2IsRUFBRSxFQUFFLElBQUk7d0JBQ1IsSUFBSSxFQUFFLE9BQU87d0JBQ2IsV0FBVyxFQUFFLEdBQUc7cUJBQ2pCLENBQUM7b0JBQ0ksS0FBSSxDQUFDLElBQUksQ0FBQyxJQUFLLENBQUMsSUFBSSxDQUFDO3dCQUN6QixHQUFHLEtBQUE7d0JBQ0gsUUFBUSxFQUFFLGNBQVEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO3FCQUNyQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1YsS0FBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDeEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixLQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQTtnQkFDckMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ3ZELEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxLQUFLLEVBQWlCLENBQUM7Z0JBQ3BDLEdBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztvQkFDM0IsS0FBSyxDQUFDLElBQUksQ0FBQzt3QkFDVCxHQUFHLEtBQUE7d0JBQ0gsUUFBUSxFQUFFLGNBQVEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO3FCQUNyQyxDQUFDLENBQUE7b0JBQ0YsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7d0JBQzNCLElBQUksU0FBUyxTQUFNLEVBQ2pCLE9BQU8sU0FBTSxFQUNiLE9BQW9CLENBQUM7d0JBQ3ZCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTt3QkFDM0IsU0FBUyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQzt3QkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzt3QkFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO3dCQUN4QyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUVoQyxJQUFJLE1BQU0sR0FBaUIsQ0FBQyxJQUFJLGFBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLGFBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLGFBQUssQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLGFBQUssQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLGFBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUUvSyxPQUFLLEdBQUcsSUFBSSx3Q0FBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDeEgsS0FBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBSyxDQUFDLENBQUM7d0JBQ3pCLEtBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtvQkFHL0MsQ0FBQztnQkFFSCxDQUFDLENBQUMsQ0FBQztnQkFDSCxFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksZUFBZSxDQUFDLENBQUMsQ0FBQztvQkFDM0IsS0FBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7b0JBQ3ZCLEtBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtnQkFDbkYsQ0FBQztnQkFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JCLENBQUM7WUFDRCxLQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3Q0FBVSxHQUFWO1FBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBRUQsb0NBQU0sR0FBTjtRQUNFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDbkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDcEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzdDLElBQUk7WUFDRixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELHNDQUFRLEdBQVI7UUFDRSxJQUFJLE9BQU8sR0FBWSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztRQUNyRCxPQUFPLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUN0QyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztJQUMxQixDQUFDO0lBRUQsMkNBQWEsR0FBYixVQUFjLElBQUk7UUFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsU0FBUztjQUMxQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7Y0FDdEMsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3BHLENBQUM7SUFFRCx3Q0FBVSxHQUFWLFVBQVcsS0FBSztRQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBQzlCLENBQUM7SUFFRCxnREFBa0IsR0FBbEIsVUFBbUIsSUFBSTtRQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMvRyxDQUFDO0lBRUQsNkNBQWUsR0FBZixVQUFnQixJQUFJO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQy9HLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELHNDQUFRLEdBQVI7UUFBQSxpQkFpRkM7UUFoRkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUN2RCxTQUFTLENBQUMsVUFBQSxHQUFHO1lBQ1osS0FBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUU7aUJBQ25DLElBQUksQ0FBQyxVQUFBLFFBQVE7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2dCQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN0QixLQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO2dCQUNsRCxLQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO2dCQUNwRCxPQUFPLENBQUMsR0FBRyxDQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUN0QixLQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBUyxHQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUEsbUVBQW1FO2dCQUN4SSxLQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBUyxHQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsbUVBQW1FO2dCQUMxSSxLQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0JBRTNCLElBQUksTUFBTSxHQUFHLElBQUkscUNBQU0sRUFBRSxDQUFDO2dCQUMxQixNQUFNLENBQUMsUUFBUSxHQUFHLHVDQUFRLENBQUMsa0JBQWtCLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDL0YsTUFBTSxDQUFDLEtBQUssR0FBRyxLQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzVDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsS0FBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO2dCQUN6QyxNQUFNLENBQUMsUUFBUSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDO2dCQUMvQixNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDdEIsS0FBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9CLE1BQU0sR0FBRyxJQUFJLHFDQUFNLEVBQUUsQ0FBQztnQkFDdEIsTUFBTSxDQUFDLFFBQVEsR0FBRyx1Q0FBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLEtBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzdHLE1BQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixNQUFNLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQztnQkFDM0IsTUFBTSxDQUFDLFFBQVEsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0JBQ3RCLEtBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUUvQixNQUFNLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsVUFBVSxNQUFNO29CQUMvQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDO2dCQUNyQyxDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDakQsSUFBSSxNQUFNLEdBQUcsS0FBSSxDQUFDO2dCQUNsQixLQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ2hELEtBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxLQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7Z0JBQ2pELEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzVDLEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQztnQkFDdEQsS0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2dCQUMvQyxLQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7Z0JBQ3JELEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQztnQkFDbkQsS0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO2dCQUNuRCxLQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7Z0JBQ2pELEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztnQkFDakQsK0JBQStCO2dCQUMvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBdUJJO2dCQUVKLHlDQUF5QztnQkFDekMseUNBQXlDO2dCQUN6QyxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUN0QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQSxLQUFLO2dCQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxDQUFDLENBQUM7Z0JBQ2pELEtBQUssQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsQ0FBQztZQUM3QyxDQUFDLENBQUMsQ0FBQztRQUVQLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQztJQUVELHFDQUFPLEdBQVAsVUFBUSxJQUFJO1FBQ1YsK0VBQStFO1FBQy9FLG9CQUFvQjtRQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsZUFBZSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDckUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELHlDQUFXLEdBQVgsVUFBWSxJQUFJO1FBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFRCxxQ0FBTyxHQUFQLFVBQVEsSUFBMkI7UUFDakMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzRCxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDbEQsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDdkIsS0FBSyxDQUFDO2dCQUNKLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDO29CQUN2QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNwQixJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUU5QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3BCLENBQUM7Z0JBQ0QsS0FBSyxDQUFDO1lBQ1IsS0FBSyxDQUFDO2dCQUNKLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDekIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUM7d0JBQ3pCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQztnQkFFRCxLQUFLLENBQUM7UUFDVixDQUFDO1FBRUQ7Ozs7Ozs7OzsyQ0FTbUM7SUFDckMsQ0FBQztJQUVELHNDQUFRLEdBQVI7UUFDRSx5Q0FBeUM7UUFDekMsdUJBQXVCO1FBQ3ZCLDBCQUEwQjtJQUM1QixDQUFDO0lBamV1QjtRQUF2QixnQkFBUyxDQUFDLFdBQVcsQ0FBQztrQ0FBYSxpQkFBVTsyREFBQztJQUN0QjtRQUF4QixnQkFBUyxDQUFDLFlBQVksQ0FBQztrQ0FBWSw4QkFBb0I7MERBQUM7SUFGOUMsbUJBQW1CO1FBTC9CLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsZUFBZTtZQUN6QixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLDZCQUE2QjtTQUMzQyxDQUFDO3lDQTZCaUMsMEJBQVc7WUFDckIsMEJBQVc7WUFDUCxrQ0FBZTtZQUNkLHlCQUFnQjtZQUMzQix1QkFBYztPQWhDcEIsbUJBQW1CLENBbWUvQjtJQUFELDBCQUFDO0NBQUEsQUFuZUQsSUFtZUM7QUFuZVksa0RBQW1CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFZpZXdDaGlsZCwgRWxlbWVudFJlZiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBJdGVtIH0gZnJvbSBcIi4uLy4uL2l0ZW0vaXRlbVwiO1xuaW1wb3J0IHsgSXRlbVNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vaXRlbS9pdGVtLnNlcnZpY2VcIjtcbmltcG9ydCB7IFVzZXJTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXIuc2VydmljZVwiO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgV2ViVmlldyB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3dlYi12aWV3XCI7XG5pbXBvcnQgeyBMb2NhdGlvblNlcnZpY2UsIExvY2F0aW9uRGF0YSB9IGZyb20gXCIuLi8uLi9zaGFyZWQvbG9jYXRpb24vbG9jYXRpb24uc2VydmljZVwiO1xuaW1wb3J0IHsgTWFwVmlldywgTWFya2VyLCBQb3NpdGlvbiwgQm91bmRzIH0gZnJvbSAnbmF0aXZlc2NyaXB0LWdvb2dsZS1tYXBzLXNkayc7XG5pbXBvcnQgeyBTd2lwZUdlc3R1cmVFdmVudERhdGEgfSBmcm9tIFwidWkvZ2VzdHVyZXNcIjtcbmltcG9ydCB7IHJlZ2lzdGVyRWxlbWVudCB9IGZyb20gJ25hdGl2ZXNjcmlwdC1hbmd1bGFyL2VsZW1lbnQtcmVnaXN0cnknO1xuaW1wb3J0IHsgUmFkQ2FsZW5kYXIsIENhbGVuZGFyRXZlbnQsIENhbGVuZGFyU2VsZWN0aW9uRXZlbnREYXRhIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1jYWxlbmRhclwiO1xuaW1wb3J0IHsgUmFkQ2FsZW5kYXJDb21wb25lbnQgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLWNhbGVuZGFyL2FuZ3VsYXJcIjtcbmltcG9ydCAqIGFzIGNhbGVuZGFyTW9kdWxlIGZyb20gXCJuYXRpdmVzY3JpcHQtdWktY2FsZW5kYXJcIjtcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvY29sb3JcIjtcbmltcG9ydCAqIGFzIFROU1Bob25lIGZyb20gJ25hdGl2ZXNjcmlwdC1waG9uZSc7XG5cbnJlZ2lzdGVyRWxlbWVudCgnTWFwVmlldycsICgpID0+IE1hcFZpZXcpO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6IFwibnMtZXN0aWxvc2V2dFwiLFxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICB0ZW1wbGF0ZVVybDogXCIuL2VzdGlsb3NldnQuY29tcG9uZW50Lmh0bWxcIixcbn0pXG5leHBvcnQgY2xhc3MgRXN0aWxvc0V2dENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIEBWaWV3Q2hpbGQoXCJteVdlYlZpZXdcIikgd2ViVmlld1JlZjogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZChcIm15Q2FsZW5kYXJcIikgX2NhbGVuZGFyOiBSYWRDYWxlbmRhckNvbXBvbmVudDtcbiAgbG9jYXRpb246IExvY2F0aW9uRGF0YSA9IHsgbGF0aXR1ZGU6IDAsIGxvbmdpdHVkZTogMCwgYWx0aXR1ZGU6IDAgfTtcbiAgY3VycmVudGxvY2F0aW9uOiBMb2NhdGlvbkRhdGEgPSB7IGxhdGl0dWRlOiAwLCBsb25naXR1ZGU6IDAsIGFsdGl0dWRlOiAwIH07XG4gIHBhZ2VudW1iZXI6IG51bWJlciA9IDA7XG4gIGl0ZW06IEl0ZW07XG4gIGlzTG9hZGluZzogYm9vbGVhbiA9IGZhbHNlO1xuICBzaG93Y2FsZW5kYXI6IGJvb2xlYW4gPSBmYWxzZTtcbiAgc2hvd3dlYnZpZXc6IGJvb2xlYW4gPSBmYWxzZTtcbiAgc2hvd21hcDogYm9vbGVhbiA9IGZhbHNlO1xuICBwcml2YXRlIF92aWV3TW9kZTtcbiAgbWFwVmlldzogTWFwVmlldztcbiAgcHVibGljIGV2ZW50b3M6IGFueVtdID0gW107XG4gIGN1cmV2ZW50bzogYW55ID0gbnVsbDtcbiAgdGlwbzogYW55O1xuICB6b29tID0gMTU7XG4gIG1pblpvb20gPSAwO1xuICBtYXhab29tID0gNDA7XG4gIGJlYXJpbmcgPSAwO1xuICB0aWx0ID0gMDtcbiAgcGFkZGluZyA9IFs0MCwgNDAsIDQwLCA0MF07XG4gIGxhc3RDYW1lcmE6IFN0cmluZztcbiAgcHVibGljIF9ldmVudHM6IEFycmF5PENhbGVuZGFyRXZlbnQ+ID0gbmV3IEFycmF5PENhbGVuZGFyRXZlbnQ+KCk7O1xuICBjdXJldmVudGluZGV4OiBudW1iZXIgPSAtMTtcbiAgcHJpdmF0ZSBfbW9udGhWaWV3U3R5bGU6IGNhbGVuZGFyTW9kdWxlLkNhbGVuZGFyTW9udGhWaWV3U3R5bGU7XG4gIHByaXZhdGUgX2V2ZW50c1ZpZXdNb2RlO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaXRlbVNlcnZpY2U6IEl0ZW1TZXJ2aWNlLFxuICAgIHByaXZhdGUgdXNlclNlcnZpY2U6IFVzZXJTZXJ2aWNlLFxuICAgIHByaXZhdGUgbG9jYXRpb25TZXJ2aWNlOiBMb2NhdGlvblNlcnZpY2UsXG4gICAgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxuICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlKSB7XG4gICAgY29uc3QgaWQgPSB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcImlkY2F0ZWdvcmlhXCJdO1xuICAgIHRoaXMudGlwbyA9IHRoaXMucm91dGUuc25hcHNob3QucGFyYW1zW1widGlwb1wiXTtcbiAgICB0aGlzLml0ZW0gPSB0aGlzLml0ZW1TZXJ2aWNlLmdldEl0ZW0oaWQpO1xuICAgIHRoaXMuaXRlbS5tZW51ID0gW107XG4gICAgdGhpcy5sb2FkbGlzdCh0aGlzLml0ZW0ubWVudSwgXCJlc3RpbG9zZXZ0XCIsIFwiLTFcIik7XG4gICAgdGhpcy5fbW9udGhWaWV3U3R5bGUgPSB0aGlzLmdldE1vbnRoVmlld1N0eWxlKCk7XG4gICAgdGhpcy5fZXZlbnRzVmlld01vZGUgPSBjYWxlbmRhck1vZHVsZS5DYWxlbmRhckV2ZW50c1ZpZXdNb2RlLklubGluZTtcbiAgICB0aGlzLmV2ZW50b3MucHVzaCh7XG4gICAgICByb3c6IHsgbm9tZTogJycsIGRlc2NyaWNhbzogJycgfVxuICAgIH0pO1xuICAgIHRoaXMuY3VyZXZlbnRvID0gdGhpcy5ldmVudG9zWzBdO1xuICAgIHRoaXMuX3ZpZXdNb2RlID0gY2FsZW5kYXJNb2R1bGUuQ2FsZW5kYXJWaWV3TW9kZS5Nb250aDtcbiAgfVxuXG4gIGdldCB2aWV3TW9kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fdmlld01vZGU7XG4gIH1cblxuICBnZXQgZXZlbnRTb3VyY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2V2ZW50cztcbiAgfVxuXG4gIGxpZ2Fmb25lKCkge1xuICAgIFROU1Bob25lLmRpYWwodGhpcy5jdXJldmVudG8ucm93LmZvbmUsIGZhbHNlKTtcbiAgfVxuXG4gIHNob3dDYWxlbmRhcigpIHtcbiAgICB0aGlzLnNob3djYWxlbmRhciA9ICF0aGlzLnNob3djYWxlbmRhclxuICB9XG5cbiAgZ29Ub0N1cnJlbnREYXkoKSB7XG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgdGhpcy5fY2FsZW5kYXIubmF0aXZlRWxlbWVudC5nb1RvRGF0ZShkYXRlKTtcbiAgfVxuXG4gIHByZXZldnQoKSB7XG4gICAgaWYgKHRoaXMuY3VyZXZlbnRpbmRleCA+IDApXG4gICAgICB0aGlzLmN1cmV2ZW50aW5kZXgtLTtcbiAgICBlbHNlXG4gICAgICB0aGlzLmN1cmV2ZW50aW5kZXggPSB0aGlzLl9ldmVudHMubGVuZ3RoIC0gMTtcbiAgICB0aGlzLl9jYWxlbmRhci5uYXRpdmVFbGVtZW50LmdvVG9EYXRlKHRoaXMuX2V2ZW50c1t0aGlzLmN1cmV2ZW50aW5kZXhdLnN0YXJ0RGF0ZSlcbiAgfVxuXG4gIG5leHRldnQoKSB7XG4gICAgdGhpcy5jdXJldmVudGluZGV4ID0gKCh0aGlzLmN1cmV2ZW50aW5kZXggKyAxKSAlIHRoaXMuX2V2ZW50cy5sZW5ndGgpXG4gICAgdGhpcy5fY2FsZW5kYXIubmF0aXZlRWxlbWVudC5nb1RvRGF0ZSh0aGlzLl9ldmVudHNbdGhpcy5jdXJldmVudGluZGV4XS5zdGFydERhdGUpXG5cbiAgfVxuXG4gIGdldE1vbnRoVmlld1N0eWxlKCk6IGNhbGVuZGFyTW9kdWxlLkNhbGVuZGFyTW9udGhWaWV3U3R5bGUge1xuICAgIGNvbnN0IG1vbnRoVmlld1N0eWxlID0gbmV3IGNhbGVuZGFyTW9kdWxlLkNhbGVuZGFyTW9udGhWaWV3U3R5bGUoKTtcbiAgICAvKm1vbnRoVmlld1N0eWxlLmJhY2tncm91bmRDb2xvciA9IFwiR3JheVwiO1xuICAgIG1vbnRoVmlld1N0eWxlLnNob3dUaXRsZSA9IHRydWU7XG4gICAgbW9udGhWaWV3U3R5bGUuc2hvd1dlZWtOdW1iZXJzID0gZmFsc2U7XG4gICAgbW9udGhWaWV3U3R5bGUuc2hvd0RheU5hbWVzID0gdHJ1ZTtcblxuICAgIGNvbnN0IHRvZGF5Q2VsbFN0eWxlID0gbmV3IERheUNlbGxTdHlsZSgpO1xuICAgIHRvZGF5Q2VsbFN0eWxlLmNlbGxCYWNrZ3JvdW5kQ29sb3IgPSBcIiM2NmJiYWVcIjtcbiAgICB0b2RheUNlbGxTdHlsZS5jZWxsQm9yZGVyV2lkdGggPSAyO1xuICAgIHRvZGF5Q2VsbFN0eWxlLmNlbGxCb3JkZXJDb2xvciA9IFwiI2YxZThjYVwiO1xuICAgIHRvZGF5Q2VsbFN0eWxlLmNlbGxUZXh0Q29sb3IgPSBcIiM1YjM5MWVcIjtcbiAgICB0b2RheUNlbGxTdHlsZS5jZWxsVGV4dEZvbnROYW1lID0gXCJUaW1lcyBOZXcgUm9tYW5cIjtcbiAgICB0b2RheUNlbGxTdHlsZS5jZWxsVGV4dEZvbnRTdHlsZSA9IFwiQm9sZFwiO1xuICAgIHRvZGF5Q2VsbFN0eWxlLmNlbGxUZXh0U2l6ZSA9IDE0O1xuICAgIG1vbnRoVmlld1N0eWxlLnRvZGF5Q2VsbFN0eWxlID0gdG9kYXlDZWxsU3R5bGU7XG5cbiAgICBjb25zdCBkYXlDZWxsU3R5bGUgPSBuZXcgRGF5Q2VsbFN0eWxlKCk7XG4gICAgZGF5Q2VsbFN0eWxlLnNob3dFdmVudHNUZXh0ID0gZmFsc2U7XG4gICAgZGF5Q2VsbFN0eWxlLmV2ZW50VGV4dENvbG9yID0gXCJXaGl0ZVwiO1xuICAgIGRheUNlbGxTdHlsZS5ldmVudEZvbnROYW1lID0gXCJUaW1lcyBOZXcgUm9tYW5cIjtcbiAgICBkYXlDZWxsU3R5bGUuZXZlbnRGb250U3R5bGUgPSBcIkJvbGRJdGFsaWNcIjtcbiAgICBkYXlDZWxsU3R5bGUuZXZlbnRUZXh0U2l6ZSA9IDg7XG4gICAgZGF5Q2VsbFN0eWxlLmNlbGxBbGlnbm1lbnQgPSBcIlRvcFwiO1xuICAgIGRheUNlbGxTdHlsZS5jZWxsUGFkZGluZ0hvcml6b250YWwgPSAxMDtcbiAgICBkYXlDZWxsU3R5bGUuY2VsbFBhZGRpbmdWZXJ0aWNhbCA9IDU7XG4gICAgZGF5Q2VsbFN0eWxlLmNlbGxCYWNrZ3JvdW5kQ29sb3IgPSBcIiNmZmZmZmZcIjtcbiAgICBkYXlDZWxsU3R5bGUuY2VsbEJvcmRlcldpZHRoID0gMTtcbiAgICBkYXlDZWxsU3R5bGUuY2VsbEJvcmRlckNvbG9yID0gXCIjZjFlOGNhXCI7XG4gICAgZGF5Q2VsbFN0eWxlLmNlbGxUZXh0Q29sb3IgPSBcIiM3NDUxNTFcIjtcbiAgICBkYXlDZWxsU3R5bGUuY2VsbFRleHRGb250TmFtZSA9IFwiVGltZXMgTmV3IFJvbWFuXCI7XG4gICAgZGF5Q2VsbFN0eWxlLmNlbGxUZXh0Rm9udFN0eWxlID0gXCJCb2xkXCI7XG4gICAgZGF5Q2VsbFN0eWxlLmNlbGxUZXh0U2l6ZSA9IDEwO1xuICAgIG1vbnRoVmlld1N0eWxlLmRheUNlbGxTdHlsZSA9IGRheUNlbGxTdHlsZTtcblxuICAgIGNvbnN0IHdlZWtlbmRDZWxsU3R5bGUgPSBuZXcgRGF5Q2VsbFN0eWxlKCk7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5ldmVudFRleHRDb2xvciA9IFwiQmx1ZVZpb2xldFwiO1xuICAgIHdlZWtlbmRDZWxsU3R5bGUuZXZlbnRGb250TmFtZSA9IFwiVGltZXMgTmV3IFJvbWFuXCI7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5ldmVudEZvbnRTdHlsZSA9IFwiQm9sZEl0YWxpY1wiO1xuICAgIHdlZWtlbmRDZWxsU3R5bGUuZXZlbnRUZXh0U2l6ZSA9IDg7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsQWxpZ25tZW50ID0gXCJUb3BcIjtcbiAgICB3ZWVrZW5kQ2VsbFN0eWxlLmNlbGxQYWRkaW5nSG9yaXpvbnRhbCA9IDEwO1xuICAgIHdlZWtlbmRDZWxsU3R5bGUuY2VsbFBhZGRpbmdWZXJ0aWNhbCA9IDU7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsQmFja2dyb3VuZENvbG9yID0gXCJHcmF5XCI7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsQm9yZGVyV2lkdGggPSAxO1xuICAgIHdlZWtlbmRDZWxsU3R5bGUuY2VsbEJvcmRlckNvbG9yID0gXCIjZjFlOGNhXCI7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsVGV4dENvbG9yID0gXCIjNzQ1MTUxXCI7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsVGV4dEZvbnROYW1lID0gXCJUaW1lcyBOZXcgUm9tYW5cIjtcbiAgICB3ZWVrZW5kQ2VsbFN0eWxlLmNlbGxUZXh0Rm9udFN0eWxlID0gXCJCb2xkXCI7XG4gICAgd2Vla2VuZENlbGxTdHlsZS5jZWxsVGV4dFNpemUgPSAxMjtcbiAgICBtb250aFZpZXdTdHlsZS53ZWVrZW5kQ2VsbFN0eWxlID0gd2Vla2VuZENlbGxTdHlsZTtcblxuICAgIGNvbnN0IHNlbGVjdGVkQ2VsbFN0eWxlID0gbmV3IERheUNlbGxTdHlsZSgpO1xuICAgIHNlbGVjdGVkQ2VsbFN0eWxlLmV2ZW50VGV4dENvbG9yID0gXCJCbHVlXCI7XG4gICAgc2VsZWN0ZWRDZWxsU3R5bGUuZXZlbnRGb250TmFtZSA9IFwiVGltZXMgTmV3IFJvbWFuXCI7XG4gICAgc2VsZWN0ZWRDZWxsU3R5bGUuZXZlbnRGb250U3R5bGUgPSBcIkJvbGRcIjtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5ldmVudFRleHRTaXplID0gODtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsQWxpZ25tZW50ID0gXCJUb3BcIjtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsUGFkZGluZ0hvcml6b250YWwgPSAxMDtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsUGFkZGluZ1ZlcnRpY2FsID0gNTtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsQmFja2dyb3VuZENvbG9yID0gXCIjZGJjYmJiXCI7XG4gICAgc2VsZWN0ZWRDZWxsU3R5bGUuY2VsbEJvcmRlcldpZHRoID0gMjtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsQm9yZGVyQ29sb3IgPSBcIiM3NDUxNTFcIjtcbiAgICBzZWxlY3RlZENlbGxTdHlsZS5jZWxsVGV4dENvbG9yID0gXCJCbGFja1wiO1xuICAgIHNlbGVjdGVkQ2VsbFN0eWxlLmNlbGxUZXh0Rm9udE5hbWUgPSBcIlRpbWVzIE5ldyBSb21hblwiO1xuICAgIHNlbGVjdGVkQ2VsbFN0eWxlLmNlbGxUZXh0Rm9udFN0eWxlID0gXCJCb2xkXCI7XG4gICAgc2VsZWN0ZWRDZWxsU3R5bGUuY2VsbFRleHRTaXplID0gMTg7XG4gICAgbW9udGhWaWV3U3R5bGUuc2VsZWN0ZWREYXlDZWxsU3R5bGUgPSBzZWxlY3RlZENlbGxTdHlsZTtcblxuICAgIGNvbnN0IGRheU5hbWVDZWxsU3R5bGUgPSBuZXcgQ2VsbFN0eWxlKCk7XG4gICAgZGF5TmFtZUNlbGxTdHlsZS5jZWxsQmFja2dyb3VuZENvbG9yID0gXCIjZjFlOGNhXCI7XG4gICAgZGF5TmFtZUNlbGxTdHlsZS5jZWxsQm9yZGVyV2lkdGggPSAxO1xuICAgIGRheU5hbWVDZWxsU3R5bGUuY2VsbEJvcmRlckNvbG9yID0gXCIjNzQ1MTUxXCI7XG4gICAgZGF5TmFtZUNlbGxTdHlsZS5jZWxsVGV4dENvbG9yID0gXCIjNzQ1MTUxXCI7XG4gICAgZGF5TmFtZUNlbGxTdHlsZS5jZWxsVGV4dEZvbnROYW1lID0gXCJUaW1lcyBOZXcgUm9tYW5cIjtcbiAgICBkYXlOYW1lQ2VsbFN0eWxlLmNlbGxUZXh0Rm9udFN0eWxlID0gXCJCb2xkXCI7XG4gICAgZGF5TmFtZUNlbGxTdHlsZS5jZWxsVGV4dFNpemUgPSAxMDtcbiAgICBtb250aFZpZXdTdHlsZS5kYXlOYW1lQ2VsbFN0eWxlID0gZGF5TmFtZUNlbGxTdHlsZTtcblxuICAgIGNvbnN0IHRpdGxlQ2VsbFN0eWxlID0gbmV3IERheUNlbGxTdHlsZSgpO1xuICAgIHRpdGxlQ2VsbFN0eWxlLmNlbGxCYWNrZ3JvdW5kQ29sb3IgPSBcIiNiYmNiZGJcIjtcbiAgICB0aXRsZUNlbGxTdHlsZS5jZWxsQm9yZGVyV2lkdGggPSAxO1xuICAgIHRpdGxlQ2VsbFN0eWxlLmNlbGxCb3JkZXJDb2xvciA9IFwiIzc0NTE1MVwiO1xuICAgIHRpdGxlQ2VsbFN0eWxlLmNlbGxUZXh0Q29sb3IgPSBcIiNkZDg1NWNcIjtcbiAgICB0aXRsZUNlbGxTdHlsZS5jZWxsVGV4dEZvbnROYW1lID0gXCJUaW1lcyBOZXcgUm9tYW5cIjtcbiAgICB0aXRsZUNlbGxTdHlsZS5jZWxsVGV4dEZvbnRTdHlsZSA9IFwiQm9sZFwiO1xuICAgIHRpdGxlQ2VsbFN0eWxlLmNlbGxUZXh0U2l6ZSA9IDE4O1xuICAgIG1vbnRoVmlld1N0eWxlLnRpdGxlQ2VsbFN0eWxlID0gdGl0bGVDZWxsU3R5bGU7XG4qL1xuICAgIHJldHVybiBtb250aFZpZXdTdHlsZTtcbiAgfVxuXG4gIGdldCBtb250aFZpZXdTdHlsZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fbW9udGhWaWV3U3R5bGU7XG4gIH1cblxuICBnZXQgZXZlbnRzVmlld01vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2V2ZW50c1ZpZXdNb2RlO1xuICB9XG5cbiAgcHVibGljIHRhcGV2ZW50byhhcmdzOiBjYWxlbmRhck1vZHVsZS5DYWxlbmRhcklubGluZUV2ZW50U2VsZWN0ZWREYXRhKSB7XG4gICAgY29uc3QgY2FsZW5kYXI6IFJhZENhbGVuZGFyID0gPFJhZENhbGVuZGFyPmFyZ3Mub2JqZWN0O1xuXG4gICAgY29uc29sZS5kaXIoPGFueT5hcmdzLmV2ZW50RGF0YSk7XG4gICAgdmFyIHMgPSBhcmdzLmV2ZW50RGF0YS50aXRsZS5zcGxpdCgvWzpdLylcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuZXZlbnRvcy5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKHRoaXMuZXZlbnRvc1tpXS5yb3cuaWQgPT0gc1sxXSkge1xuICAgICAgICB0aGlzLmN1cmV2ZW50aW5kZXggPSBpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgIH1cblxuICAgIHRoaXMuZXZlbnRvY2xpY2sodGhpcy5ldmVudG9zW3RoaXMuY3VyZXZlbnRpbmRleF0pXG4gIH1cblxuXG4gIG9uRGF0ZVNlbGVjdGVkKGFyZ3M6IENhbGVuZGFyU2VsZWN0aW9uRXZlbnREYXRhKSB7XG4gICAgY29uc3QgY2FsZW5kYXI6IFJhZENhbGVuZGFyID0gYXJncy5vYmplY3Q7XG4gICAgY29uc3QgZGF0ZTogRGF0ZSA9IGFyZ3MuZGF0ZTtcbiAgICBjb25zdCBldmVudHM6IEFycmF5PENhbGVuZGFyRXZlbnQ+ID0gY2FsZW5kYXIuZ2V0RXZlbnRzRm9yRGF0ZShkYXRlKTtcbiAgfVxuXG4gIGNvbmZpZ3VyZWV2ZW50byhpdGVtKSB7XG4gICAgdmFyIHQgPSBpdGVtLnJvdy5kYXRhaG9yYXJpby5zcGxpdCgvWy0gOl0vKTtcbiAgICB2YXIgZGF0YSA9IG5ldyBEYXRlKERhdGUuVVRDKHRbMF0sIHRbMV0gLSAxLCB0WzJdLCB0WzNdLCB0WzRdLCB0WzVdKSk7XG4gICAgdCA9IGl0ZW0ucm93LmRhdGFmaW0uc3BsaXQoL1stIDpdLyk7XG4gICAgdmFyIGRhdGFmaW0gPSBuZXcgRGF0ZShEYXRlLlVUQyh0WzBdLCB0WzFdIC0gMSwgdFsyXSwgdFszXSwgdFs0XSwgdFs1XSkpO1xuICAgIHZhciBzZW1hbmEgPSBbXCJEb21pbmdvXCIsIFwiU2VndW5kYS1GZWlyYVwiLCBcIlRlcsOnYS1GZWlyYVwiLCBcIlF1YXJ0YS1GZWlyYVwiLCBcIlF1aW50YS1GZWlyYVwiLCBcIlNleHRhLUZlaXJhXCIsIFwiU8OhYmFkb1wiXTtcbiAgICB2YXIgbWVzZXMgPSBbXCJKQU5cIiwgXCJGRVZcIiwgXCJNQVJcIiwgXCJBQlJcIiwgXCJNQUlcIiwgXCJKVU5cIiwgXCJKVUxcIiwgXCJBR09cIiwgXCJTRVRcIiwgXCJPVVRcIiwgXCJOT1ZcIiwgXCJERVpcIl07XG4gICAgdmFyIGFicmV2c2VtID0gW1wiRE9NXCIsIFwiU0VHXCIsIFwiVEVSXCIsIFwiUVVBXCIsIFwiUVVJXCIsIFwiU0VYXCIsIFwiU0FCXCJdXG4gICAgdmFyIGRpYW1lcyA9IGRhdGEuZ2V0VVRDRGF0ZSgpIDwgMTAgPyBcIjBcIiArIGRhdGEuZ2V0VVRDRGF0ZSgpIDogZGF0YS5nZXRVVENEYXRlKCk7XG4gICAgdmFyIG1lcyA9IGRhdGEuZ2V0VVRDTW9udGgoKSA8IDkgPyBcIjBcIiArIChkYXRhLmdldFVUQ01vbnRoKCkgKyAxKSA6IChkYXRhLmdldFVUQ01vbnRoKCkgKyAxKTtcbiAgICB2YXIgaG9yYSA9IGRhdGEuZ2V0VVRDSG91cnMoKSA8IDEwID8gXCIwXCIgKyBkYXRhLmdldFVUQ0hvdXJzKCkgOiBkYXRhLmdldFVUQ0hvdXJzKCk7XG4gICAgdmFyIG1pbnV0b3MgPSBkYXRhLmdldFVUQ01pbnV0ZXMoKSA8IDEwID8gXCIwXCIgKyBkYXRhLmdldFVUQ01pbnV0ZXMoKSA6IGRhdGEuZ2V0VVRDTWludXRlcygpO1xuICAgIHZhciBob3JhZmltID0gZGF0YWZpbS5nZXRVVENIb3VycygpIDwgMTAgPyBcIjBcIiArIGRhdGFmaW0uZ2V0VVRDSG91cnMoKSA6IGRhdGFmaW0uZ2V0VVRDSG91cnMoKTtcbiAgICB2YXIgbWludXRvc2ZpbSA9IGRhdGFmaW0uZ2V0VVRDTWludXRlcygpIDwgMTAgPyBcIjBcIiArIGRhdGFmaW0uZ2V0VVRDTWludXRlcygpIDogZGF0YWZpbS5nZXRVVENNaW51dGVzKCk7XG5cbiAgICBpdGVtLnJvdy5kYXRhID0gZGlhbWVzICsgXCJcXFxcXCIgKyBtZXMgKyBcIlxcXFxcIiArIGRhdGEuZ2V0VVRDRnVsbFllYXIoKSArIFwiIC0gXCIgKyBzZW1hbmFbZGF0YS5nZXREYXkoKV07XG4gICAgaXRlbS5yb3cudGltZSA9IGhvcmEgKyBcIjpcIiArIG1pbnV0b3M7XG4gICAgaXRlbS5yb3cudGltZWZpbSA9IGhvcmFmaW0gKyBcIjpcIiArIG1pbnV0b3NmaW07XG4gICAgaXRlbS5yb3cuYWJyZXZtZXMgPSBtZXNlc1tkYXRhLmdldFVUQ01vbnRoKCldO1xuICAgIGl0ZW0ucm93LmFicmV2c2VtID0gYWJyZXZzZW1bZGF0YS5nZXREYXkoKV07XG4gICAgaXRlbS5yb3cuZGlhbWVzID0gZGlhbWVzO1xuICB9XG5cbiAgd2ViVmlld1RvdWNoKGV2ZW50KXtcbiAgICBcbiAgfVxuXG4gIHdlYlZpZXdQYW4oZXZlbnQpe1xuXG4gIH1cblxuICBsb2FkbGlzdChhcnJheSwga2V5LCBpZGVzdGlsbykge1xuICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICB0aGlzLnVzZXJTZXJ2aWNlLmRiXG4gICAgICAuZ2V0KGVuY29kZVVSSShcImtleT1cIiArIGtleSArXG4gICAgICAgIFwiJmlkY2F0ZWdvcmlhPVwiICsgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpZGNhdGVnb3JpYVwiXSArXG4gICAgICAgIFwiJmNpZGFkZT1cIiArIHRoaXMucm91dGUuc25hcHNob3QucGFyYW1zW1wiY2lkYWRlXCJdICtcbiAgICAgICAgXCImdWY9XCIgKyB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcInVmXCJdICtcbiAgICAgICAgXCImaWRlc3RpbG89XCIgKyBpZGVzdGlsbykpXG4gICAgICAuc3Vic2NyaWJlKHJlcyA9PiB7XG4gICAgICAgIGlmIChyZXMgIT0gbnVsbCkge1xuICAgICAgICAgIGlmIChrZXkgPT0gXCJlc3RpbG9zZXZ0XCIpIHtcbiAgICAgICAgICAgIHZhciByb3c6IGFueSA9IHtcbiAgICAgICAgICAgICAgaWQ6IFwiLTFcIixcbiAgICAgICAgICAgICAgbm9tZTogXCJUT0RPU1wiLFxuICAgICAgICAgICAgICBpZGNhdGVnb3JpYTogXCIxXCJcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICAoPGFueT50aGlzLml0ZW0ubWVudSkucHVzaCh7XG4gICAgICAgICAgICAgIHJvdyxcbiAgICAgICAgICAgICAgdG9TdHJpbmc6ICgpID0+IHsgcmV0dXJuIHJvdy5ub21lOyB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgICB0aGlzLmN1cmV2ZW50aW5kZXggPSAtMTtcbiAgICAgICAgICB0aGlzLmdvVG9DdXJyZW50RGF5KCk7XG4gICAgICAgICAgdGhpcy5fY2FsZW5kYXIubmF0aXZlRWxlbWVudC5yZWxvYWQoKVxuICAgICAgICAgIHRoaXMuX2NhbGVuZGFyLm5hdGl2ZUVsZW1lbnQuc2VsZWN0ZWREYXRlID0gbmV3IERhdGUoKTtcbiAgICAgICAgICB0aGlzLl9ldmVudHMgPSBuZXcgQXJyYXk8Q2FsZW5kYXJFdmVudD4oKTtcbiAgICAgICAgICAoPGFueT5yZXMpLnJlc3VsdC5mb3JFYWNoKHJvdyA9PiB7XG4gICAgICAgICAgICBhcnJheS5wdXNoKHtcbiAgICAgICAgICAgICAgcm93LFxuICAgICAgICAgICAgICB0b1N0cmluZzogKCkgPT4geyByZXR1cm4gcm93Lm5vbWU7IH0sXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgaWYgKGtleSA9PSBcImV2ZW50b3NyZWdpYW9cIikge1xuICAgICAgICAgICAgICBsZXQgc3RhcnREYXRlOiBEYXRlLFxuICAgICAgICAgICAgICAgIGVuZERhdGU6IERhdGUsXG4gICAgICAgICAgICAgICAgZXZlbnQ6IENhbGVuZGFyRXZlbnQ7XG4gICAgICAgICAgICAgIHZhciB0ID0gcm93LmRhdGFob3JhcmlvLnNwbGl0KC9bLSA6XS8pO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImhvcmE9XCIgKyB0WzNdKVxuICAgICAgICAgICAgICBzdGFydERhdGUgPSBuZXcgRGF0ZShyb3cuZGF0YWhvcmFyaW8pO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhzdGFydERhdGUudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKChuZXcgRGF0ZSgpKS50b1VUQ1N0cmluZygpKTtcbiAgICAgICAgICAgICAgZW5kRGF0ZSA9IG5ldyBEYXRlKHJvdy5kYXRhZmltKTtcblxuICAgICAgICAgICAgICBsZXQgY29sb3JzOiBBcnJheTxDb2xvcj4gPSBbbmV3IENvbG9yKDIwMCwgMTg4LCAyNiwgMjE0KSwgbmV3IENvbG9yKDIyMCwgMjU1LCAxMDksIDEzMCksIG5ldyBDb2xvcigyNTUsIDU1LCA0NSwgMjU1KSwgbmV3IENvbG9yKDE5OSwgMTcsIDIyNywgMTApLCBuZXcgQ29sb3IoMjU1LCAyNTUsIDU0LCAzKV07XG5cbiAgICAgICAgICAgICAgZXZlbnQgPSBuZXcgQ2FsZW5kYXJFdmVudChyb3cubm9tZSArIFwiOlwiICsgcm93LmlkLCBzdGFydERhdGUsIGVuZERhdGUsIGZhbHNlLCBjb2xvcnNbKGkrKykgKiAxMCAlIChjb2xvcnMubGVuZ3RoIC0gMSldKTtcbiAgICAgICAgICAgICAgdGhpcy5fZXZlbnRzLnB1c2goZXZlbnQpO1xuICAgICAgICAgICAgICB0aGlzLmNvbmZpZ3VyZWV2ZW50byhhcnJheVthcnJheS5sZW5ndGggLSAxXSlcblxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAoa2V5ID09IFwiZXZlbnRvc3JlZ2lhb1wiKSB7XG4gICAgICAgICAgICB0aGlzLmN1cmV2ZW50aW5kZXggPSAwO1xuICAgICAgICAgICAgdGhpcy5fY2FsZW5kYXIubmF0aXZlRWxlbWVudC5nb1RvRGF0ZSh0aGlzLl9ldmVudHNbdGhpcy5jdXJldmVudGluZGV4XS5zdGFydERhdGUpXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY29uc29sZS5kaXIoYXJyYXkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICB9KTtcbiAgfVxuXG4gIGdvdG9jdXJkYXkoKSB7XG4gICAgdGhpcy5fY2FsZW5kYXIubmF0aXZlRWxlbWVudC5nb1RvRGF0ZShuZXcgRGF0ZSgpKVxuICB9XG5cbiAgZ29iYWNrKCkge1xuICAgIGlmICh0aGlzLnNob3d3ZWJ2aWV3KVxuICAgICAgdGhpcy5zaG93d2VidmlldyA9IGZhbHNlO1xuICAgIGVsc2UgaWYgKHRoaXMuc2hvd21hcClcbiAgICAgIHRoaXMuc2hvd21hcCA9IGZhbHNlO1xuICAgIGVsc2UgaWYgKHRoaXMucGFnZW51bWJlciA9PSAwKVxuICAgICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLmJhY2tUb1ByZXZpb3VzUGFnZSgpO1xuICAgIGVsc2VcbiAgICAgIHRoaXMucGFnZW51bWJlci0tO1xuICB9XG5cbiAgYWJyZXNpdGUoKSB7XG4gICAgbGV0IHdlYnZpZXc6IFdlYlZpZXcgPSB0aGlzLndlYlZpZXdSZWYubmF0aXZlRWxlbWVudDtcbiAgICB3ZWJ2aWV3LnNyYyA9IHRoaXMuY3VyZXZlbnRvLnJvdy5zaXRlO1xuICAgIHRoaXMuc2hvd3dlYnZpZXcgPSB0cnVlO1xuICB9XG5cbiAgb25NYXJrZXJFdmVudChhcmdzKSB7XG4gICAgY29uc29sZS5sb2coXCJNYXJrZXIgRXZlbnQ6ICdcIiArIGFyZ3MuZXZlbnROYW1lXG4gICAgICArIFwiJyB0cmlnZ2VyZWQgb246IFwiICsgYXJncy5tYXJrZXIudGl0bGVcbiAgICAgICsgXCIsIExhdDogXCIgKyBhcmdzLm1hcmtlci5wb3NpdGlvbi5sYXRpdHVkZSArIFwiLCBMb246IFwiICsgYXJncy5tYXJrZXIucG9zaXRpb24ubG9uZ2l0dWRlLCBhcmdzKTtcbiAgfVxuXG4gIG9uTWFwUmVhZHkoZXZlbnQpIHtcbiAgICBjb25zb2xlLmxvZygnTWFwIFJlYWR5Jyk7XG4gICAgdGhpcy5tYXBWaWV3ID0gZXZlbnQub2JqZWN0O1xuICB9XG5cbiAgb25Db29yZGluYXRlVGFwcGVkKGFyZ3MpIHtcbiAgICBjb25zb2xlLmxvZyhcIkNvb3JkaW5hdGUgVGFwcGVkLCBMYXQ6IFwiICsgYXJncy5wb3NpdGlvbi5sYXRpdHVkZSArIFwiLCBMb246IFwiICsgYXJncy5wb3NpdGlvbi5sb25naXR1ZGUsIGFyZ3MpO1xuICB9XG5cbiAgb25DYW1lcmFDaGFuZ2VkKGFyZ3MpIHtcbiAgICBjb25zb2xlLmxvZyhcIkNhbWVyYSBjaGFuZ2VkOiBcIiArIEpTT04uc3RyaW5naWZ5KGFyZ3MuY2FtZXJhKSwgSlNPTi5zdHJpbmdpZnkoYXJncy5jYW1lcmEpID09PSB0aGlzLmxhc3RDYW1lcmEpO1xuICAgIHRoaXMubGFzdENhbWVyYSA9IEpTT04uc3RyaW5naWZ5KGFyZ3MuY2FtZXJhKTtcbiAgfVxuXG4gIGFicmVtYXBhKCkge1xuICAgIHRoaXMubG9jYXRpb25TZXJ2aWNlLmdldGxhdGxvbmdGcm9tRW5kKHRoaXMuY3VyZXZlbnRvLnJvdylcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgdGhpcy5sb2NhdGlvblNlcnZpY2UuZ2V0TG9jYXRpb25PbmNlKClcbiAgICAgICAgICAudGhlbihsb2NhdGlvbiA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkxvY2F0aW9uIHJlY2VpdmVkOiBcIik7XG4gICAgICAgICAgICBjb25zb2xlLmRpcihsb2NhdGlvbik7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRsb2NhdGlvbi5sYXRpdHVkZSA9IGxvY2F0aW9uLmxhdGl0dWRlO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50bG9jYXRpb24ubG9uZ2l0dWRlID0gbG9jYXRpb24ubG9uZ2l0dWRlO1xuICAgICAgICAgICAgY29uc29sZS5kaXIoPGFueT5yZXMpO1xuICAgICAgICAgICAgdGhpcy5sb2NhdGlvbi5sYXRpdHVkZSA9ICg8YW55PnJlcykucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbi5sYXQ7Ly9sb2NhdGlvbi5sYXRpdHVkZTsvLyAoPGFueT5yZXMpLnJlc3VsdHNbMF0uZ2VvbWV0cnkubG9jYXRpb24ubGF0O1xuICAgICAgICAgICAgdGhpcy5sb2NhdGlvbi5sb25naXR1ZGUgPSAoPGFueT5yZXMpLnJlc3VsdHNbMF0uZ2VvbWV0cnkubG9jYXRpb24ubG5nOyAvL2xvY2F0aW9uLmxvbmdpdHVkZTsvLyg8YW55PnJlcykucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbi5sbmc7XG4gICAgICAgICAgICB0aGlzLmxvY2F0aW9uLmFsdGl0dWRlID0gMDtcblxuICAgICAgICAgICAgdmFyIG1hcmtlciA9IG5ldyBNYXJrZXIoKTtcbiAgICAgICAgICAgIG1hcmtlci5wb3NpdGlvbiA9IFBvc2l0aW9uLnBvc2l0aW9uRnJvbUxhdExuZyh0aGlzLmxvY2F0aW9uLmxhdGl0dWRlLCB0aGlzLmxvY2F0aW9uLmxvbmdpdHVkZSk7XG4gICAgICAgICAgICBtYXJrZXIudGl0bGUgPSB0aGlzLmN1cmV2ZW50by5yb3cubm9tZWxvY2FsO1xuICAgICAgICAgICAgbWFya2VyLnNuaXBwZXQgPSB0aGlzLmN1cmV2ZW50by5yb3cubm9tZTtcbiAgICAgICAgICAgIG1hcmtlci51c2VyRGF0YSA9IHsgaW5kZXg6IDAgfTtcbiAgICAgICAgICAgIG1hcmtlci52aXNpYmxlID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMubWFwVmlldy5hZGRNYXJrZXIobWFya2VyKTtcbiAgICAgICAgICAgIG1hcmtlciA9IG5ldyBNYXJrZXIoKTtcbiAgICAgICAgICAgIG1hcmtlci5wb3NpdGlvbiA9IFBvc2l0aW9uLnBvc2l0aW9uRnJvbUxhdExuZyh0aGlzLmN1cnJlbnRsb2NhdGlvbi5sYXRpdHVkZSwgdGhpcy5jdXJyZW50bG9jYXRpb24ubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgIG1hcmtlci50aXRsZSA9IFwiRVVcIjtcbiAgICAgICAgICAgIG1hcmtlci5zbmlwcGV0ID0gXCJib3JhIGzDoVwiO1xuICAgICAgICAgICAgbWFya2VyLnVzZXJEYXRhID0geyBpbmRleDogMSB9O1xuICAgICAgICAgICAgbWFya2VyLnZpc2libGUgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5tYXBWaWV3LmFkZE1hcmtlcihtYXJrZXIpO1xuXG4gICAgICAgICAgICBtYXJrZXIgPSB0aGlzLm1hcFZpZXcuZmluZE1hcmtlcihmdW5jdGlvbiAobWFya2VyKSB7XG4gICAgICAgICAgICAgIHJldHVybiBtYXJrZXIudXNlckRhdGEuaW5kZXggPT09IDE7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTW92aW5nIG1hcmtlci4uLlwiLCBtYXJrZXIudXNlckRhdGEpO1xuICAgICAgICAgICAgdmFyIF9fdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICB0aGlzLmxvY2F0aW9uU2VydmljZS5zdGFydHdhdGNoKF9fdGhpcywgbWFya2VyKTtcbiAgICAgICAgICAgIHRoaXMubWFwVmlldy5teUxvY2F0aW9uRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm1hcFZpZXcuc2V0dGluZ3Muem9vbUNvbnRyb2xzRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm1hcFZpZXcuc2V0dGluZ3MuY29tcGFzc0VuYWJsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5tYXBWaWV3LnNldHRpbmdzLmluZG9vckxldmVsUGlja2VyRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm1hcFZpZXcuc2V0dGluZ3MubWFwVG9vbGJhckVuYWJsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5tYXBWaWV3LnNldHRpbmdzLm15TG9jYXRpb25CdXR0b25FbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMubWFwVmlldy5zZXR0aW5ncy5yb3RhdGVHZXN0dXJlc0VuYWJsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5tYXBWaWV3LnNldHRpbmdzLnNjcm9sbEdlc3R1cmVzRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm1hcFZpZXcuc2V0dGluZ3MudGlsdEdlc3R1cmVzRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm1hcFZpZXcuc2V0dGluZ3Muem9vbUdlc3R1cmVzRW5hYmxlZCA9IHRydWU7XG4gICAgICAgICAgICAvLyoqKiAgc2V0Vmlld3BvcnQgbsOjbyBmdW5jaW9uYVxuICAgICAgICAgICAgLyp2YXIgc291dGh3ZXN0PVBvc2l0aW9uLnBvc2l0aW9uRnJvbUxhdExuZyh0aGlzLnN0YXJ0cG9pbnRMYXRpdHVkZSx0aGlzLnN0YXJ0cG9pbnRMb25naXR1ZGUpLFxuICAgICAgICAgICAgIG5vcnRoZWFzdD1Qb3NpdGlvbi5wb3NpdGlvbkZyb21MYXRMbmcodGhpcy5sYXRpdHVkZSx0aGlzLmxvbmdpdHVkZSk7XG4gICAgICAgICAgICAgbGV0IHRtcGxhdD1zb3V0aHdlc3QubGF0aXR1ZGU7XG4gICAgICAgICAgICAgc291dGh3ZXN0LmxhdGl0dWRlPU1hdGgubWluKHNvdXRod2VzdC5sYXRpdHVkZSxub3J0aGVhc3QubGF0aXR1ZGUpO1xuICAgICAgICAgICAgIG5vcnRoZWFzdC5sYXRpdHVkZT1NYXRoLm1heCh0bXBsYXQsbm9ydGhlYXN0LmxhdGl0dWRlKTtcbiAgICAgICAgICAgICB0bXBsYXQ9c291dGh3ZXN0LmxvbmdpdHVkZTtcbiAgICAgICAgICAgICBzb3V0aHdlc3QubG9uZ2l0dWRlPU1hdGgubWF4KHNvdXRod2VzdC5sb25naXR1ZGUsbm9ydGhlYXN0LmxvbmdpdHVkZSk7XG4gICAgICAgICAgICAgbm9ydGhlYXN0LmxvbmdpdHVkZT1NYXRoLm1pbih0bXBsYXQsbm9ydGhlYXN0LmxvbmdpdHVkZSk7XG5cbiAgICAgICAgICAgICBsZXQgdmlld3BvcnQgPSB7XG4gICAgICAgICAgICAgIHNvdXRod2VzdDoge1xuICAgICAgICAgICAgICAgICAgbGF0aXR1ZGU6IHNvdXRod2VzdC5sYXRpdHVkZSArIDAuMDAxLFxuICAgICAgICAgICAgICAgICAgbG9uZ2l0dWRlOiBub3J0aGVhc3QubG9uZ2l0dWRlICsgMC4wMDFcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbm9ydGhlYXN0OiB7XG4gICAgICAgICAgICAgICAgICBsYXRpdHVkZTogbm9ydGhlYXN0LmxhdGl0dWRlIC0gMC4wMDEsXG4gICAgICAgICAgICAgICAgICBsb25naXR1ZGU6IHNvdXRod2VzdC5sb25naXR1ZGUgLSAwLjAwMVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgYm91bmRzPUJvdW5kcy5mcm9tQ29vcmRpbmF0ZXMoXG4gICAgICAgICAgICAgIFBvc2l0aW9uLnBvc2l0aW9uRnJvbUxhdExuZyh2aWV3cG9ydC5zb3V0aHdlc3QubGF0aXR1ZGUsdmlld3BvcnQuc291dGh3ZXN0LmxvbmdpdHVkZSksXG4gICAgICAgICAgICAgIFBvc2l0aW9uLnBvc2l0aW9uRnJvbUxhdExuZyh2aWV3cG9ydC5ub3J0aGVhc3QubGF0aXR1ZGUsdmlld3BvcnQubm9ydGhlYXN0LmxvbmdpdHVkZSlcbiAgICAgICAgICAgICk7Ki9cblxuICAgICAgICAgICAgLy8gdGhpcy5tYXBWaWV3LnNldFZpZXdwb3J0KGJvdW5kcywgMTAwKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5kaXIoYm91bmRzLnNvdXRod2VzdC5sYXRpdHVkZSk7XG4gICAgICAgICAgICB0aGlzLnNob3dtYXAgPSB0cnVlO1xuICAgICAgICAgIH0pLmNhdGNoKGVycm9yID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTG9jYXRpb24gZXJyb3IgcmVjZWl2ZWQ6IFwiICsgZXJyb3IpO1xuICAgICAgICAgICAgYWxlcnQoXCJMb2NhdGlvbiBlcnJvciByZWNlaXZlZDogXCIgKyBlcnJvcik7XG4gICAgICAgICAgfSk7XG5cbiAgICAgIH0pO1xuXG4gIH1cblxuICBvbmNsaWNrKGl0ZW0pIHtcbiAgICAvLyB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL2l0ZW0vXCIraXRlbS5pZF0sIHsgY2xlYXJIaXN0b3J5OiBmYWxzZSB9KTtcbiAgICAvL3RoaXMuY3VyZXZlbnRvPVtdO1xuICAgIHRoaXMuY3VyZXZlbnRvID0gbnVsbDtcbiAgICB0aGlzLmV2ZW50b3MgPSBbXTtcbiAgICB0aGlzLmxvYWRsaXN0KHRoaXMuZXZlbnRvcywgXCJldmVudG9zcmVnaWFvXCIsIGl0ZW0ucm93LmlkLnRvU3RyaW5nKCkpO1xuICAgIGNvbnNvbGUuZGlyKGl0ZW0pO1xuICAgIHRoaXMucGFnZW51bWJlcisrO1xuICB9XG5cbiAgZXZlbnRvY2xpY2soaXRlbSkge1xuICAgIHRoaXMuY3VyZXZlbnRvID0gaXRlbTtcbiAgICB0aGlzLnBhZ2VudW1iZXIrKztcbiAgICBjb25zb2xlLmRpcih0aGlzLmN1cmV2ZW50byk7XG4gIH1cblxuICBvblN3aXBlKGFyZ3M6IFN3aXBlR2VzdHVyZUV2ZW50RGF0YSkge1xuICAgIGNvbnNvbGUubG9nKFwiU3dpcGUhXCIpO1xuICAgIGNvbnNvbGUubG9nKFwiT2JqZWN0IHRoYXQgdHJpZ2dlcmVkIHRoZSBldmVudDogXCIgKyBhcmdzLm9iamVjdCk7XG4gICAgY29uc29sZS5sb2coXCJWaWV3IHRoYXQgdHJpZ2dlcmVkIHRoZSBldmVudDogXCIgKyBhcmdzLnZpZXcpO1xuICAgIGNvbnNvbGUubG9nKFwiRXZlbnQgbmFtZTogXCIgKyBhcmdzLmV2ZW50TmFtZSk7XG4gICAgY29uc29sZS5sb2coXCJTd2lwZSBEaXJlY3Rpb246IFwiICsgYXJncy5kaXJlY3Rpb24pO1xuICAgIHN3aXRjaCAoYXJncy5kaXJlY3Rpb24pIHtcbiAgICAgIGNhc2UgMTpcbiAgICAgICAgaWYgKHRoaXMucGFnZW51bWJlciA9PSAwKVxuICAgICAgICAgIHRoaXMuZ29iYWNrKCk7XG4gICAgICAgIGVsc2UgaWYgKHRoaXMucGFnZW51bWJlciA+IDEpXG4gICAgICAgICAgdGhpcy5wYWdlbnVtYmVyLS07XG4gICAgICAgIGVsc2UgaWYgKHRoaXMucGFnZW51bWJlciA9PSAxKSB7XG5cbiAgICAgICAgICB0aGlzLnBhZ2VudW1iZXItLTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMjpcbiAgICAgICAgaWYgKHRoaXMucGFnZW51bWJlciA9PSAxKSB7XG4gICAgICAgICAgaWYgKHRoaXMuY3VyZXZlbnRvICE9IG51bGwpXG4gICAgICAgICAgICB0aGlzLnBhZ2VudW1iZXIrKztcbiAgICAgICAgfVxuXG4gICAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIC8qIGNvbnNvbGUubG9nKFwiUGFuIVwiKTtcbiAgICAgICAgIGNvbnNvbGUubG9nKFwiT2JqZWN0IHRoYXQgdHJpZ2dlcmVkIHRoZSBldmVudDogXCIgKyBhcmdzLm9iamVjdCk7XG4gICAgICAgICBjb25zb2xlLmxvZyhcIlZpZXcgdGhhdCB0cmlnZ2VyZWQgdGhlIGV2ZW50OiBcIiArIGFyZ3Mudmlldyk7XG4gICAgICAgICBjb25zb2xlLmxvZyhcIkV2ZW50IG5hbWU6IFwiICsgYXJncy5ldmVudE5hbWUpO1xuICAgICAgICAgY29uc29sZS5sb2coXCJQYW4gZGVsdGE6IFtcIiArIGFyZ3MuZGVsdGFYICsgXCIsIFwiICsgYXJncy5kZWx0YVkgKyBcIl0gc3RhdGU6IFwiICsgYXJncy5zdGF0ZSk7XG4gXG4gICAgICAgICB0aGlzLmRlbHRhWCA9IGFyZ3MuZGVsdGFYO1xuICAgICAgICAgdGhpcy5kZWx0YVkgPSBhcmdzLmRlbHRhWTtcbiAgICAgICAgIHRoaXMuc3RhdGUgPSBhcmdzLnN0YXRlO1xuICAgICB0aGlzLmRpcmVjdGlvbiA9IGFyZ3MuZGlyZWN0aW9uOyovXG4gIH1cblxuICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAvL3RoaXMuaXRlbSA9IHRoaXMuaXRlbVNlcnZpY2UuZ2V0SXRlbSgpO1xuICAgIC8vY29uc29sZS5sb2coXCJpdGVtc1wiKTtcbiAgICAvL2NvbnNvbGUuZGlyKHRoaXMuaXRlbXMpO1xuICB9XG59Il19