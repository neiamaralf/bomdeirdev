"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var login_component_1 = require("./pages/login/login.component");
var estilosevt_component_1 = require("./pages/estilos/estilosevt.component");
var items_component_1 = require("./item/items.component");
var item_detail_component_1 = require("./item/item-detail.component");
var subitem_detail_component_1 = require("./item/subitem-detail.component");
var cep_1 = require("./item/cep");
var eventos_1 = require("./item/eventos");
var buscacep_1 = require("./item/buscacep");
var locais_1 = require("./item/locais");
var routes = [
    { path: "", component: login_component_1.LoginComponent },
    { path: "items/:cidade/:uf/:tipo", component: items_component_1.ItemsComponent },
    { path: "estilos/:idcategoria/:cidade/:uf/:tipo", component: estilosevt_component_1.EstilosEvtComponent },
    { path: "subitem/:id", component: subitem_detail_component_1.SubItemDetailComponent },
    { path: "item/:id", component: item_detail_component_1.ItemDetailComponent },
    { path: "cep/:itemid/:idcategoria/:idadmin", component: cep_1.CepComponent },
    { path: "eventos/:itemid/:acao/:idcategoria/:idadmin", component: eventos_1.EventosComponent },
    { path: "buscacep/:itemid/:idcategoria/:idadmin", component: buscacep_1.BuscaCepComponent },
    { path: "locais/:itemid/:acao/:cep/:logradouro/:bairro/:localidade/:uf/:idcategoria/:idadmin", component: locais_1.LocaisComponent },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLXJvdXRpbmcubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBwLXJvdXRpbmcubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlDO0FBRXpDLHNEQUF1RTtBQUN2RSxpRUFBK0Q7QUFDL0QsNkVBQTJFO0FBQzNFLDBEQUF3RDtBQUN4RCxzRUFBbUU7QUFDbkUsNEVBQXlFO0FBQ3pFLGtDQUEwQztBQUMxQywwQ0FBa0Q7QUFDbEQsNENBQW9EO0FBQ3BELHdDQUFnRDtBQUVoRCxJQUFNLE1BQU0sR0FBVztJQUNuQixFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLGdDQUFjLEVBQUc7SUFDeEMsRUFBRSxJQUFJLEVBQUUseUJBQXlCLEVBQUUsU0FBUyxFQUFFLGdDQUFjLEVBQUU7SUFDOUQsRUFBRSxJQUFJLEVBQUUsd0NBQXdDLEVBQUUsU0FBUyxFQUFFLDBDQUFtQixFQUFFO0lBQ2xGLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaURBQXNCLEVBQUU7SUFDMUQsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSwyQ0FBbUIsRUFBRTtJQUNwRCxFQUFFLElBQUksRUFBRSxtQ0FBbUMsRUFBRSxTQUFTLEVBQUUsa0JBQVksRUFBRTtJQUN0RSxFQUFFLElBQUksRUFBRSw2Q0FBNkMsRUFBRSxTQUFTLEVBQUUsMEJBQWdCLEVBQUU7SUFDcEYsRUFBRSxJQUFJLEVBQUUsd0NBQXdDLEVBQUUsU0FBUyxFQUFFLDRCQUFpQixFQUFFO0lBQ2hGLEVBQUUsSUFBSSxFQUFFLHFGQUFxRixFQUFFLFNBQVMsRUFBRSx3QkFBZSxFQUFFO0NBQzlILENBQUM7QUFNRjtJQUFBO0lBQWdDLENBQUM7SUFBcEIsZ0JBQWdCO1FBSjVCLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRSxDQUFDLGlDQUF3QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNuRCxPQUFPLEVBQUUsQ0FBQyxpQ0FBd0IsQ0FBQztTQUN0QyxDQUFDO09BQ1csZ0JBQWdCLENBQUk7SUFBRCx1QkFBQztDQUFBLEFBQWpDLElBQWlDO0FBQXBCLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJvdXRlcyB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IExvZ2luQ29tcG9uZW50IH0gZnJvbSBcIi4vcGFnZXMvbG9naW4vbG9naW4uY29tcG9uZW50XCI7XG5pbXBvcnQgeyBFc3RpbG9zRXZ0Q29tcG9uZW50IH0gZnJvbSBcIi4vcGFnZXMvZXN0aWxvcy9lc3RpbG9zZXZ0LmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgSXRlbXNDb21wb25lbnQgfSBmcm9tIFwiLi9pdGVtL2l0ZW1zLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgSXRlbURldGFpbENvbXBvbmVudCB9IGZyb20gXCIuL2l0ZW0vaXRlbS1kZXRhaWwuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBTdWJJdGVtRGV0YWlsQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9zdWJpdGVtLWRldGFpbC5jb21wb25lbnRcIjtcbmltcG9ydCB7IENlcENvbXBvbmVudCB9IGZyb20gXCIuL2l0ZW0vY2VwXCI7XG5pbXBvcnQgeyBFdmVudG9zQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9ldmVudG9zXCI7XG5pbXBvcnQgeyBCdXNjYUNlcENvbXBvbmVudCB9IGZyb20gXCIuL2l0ZW0vYnVzY2FjZXBcIjtcbmltcG9ydCB7IExvY2Fpc0NvbXBvbmVudCB9IGZyb20gXCIuL2l0ZW0vbG9jYWlzXCI7XG5cbmNvbnN0IHJvdXRlczogUm91dGVzID0gW1xuICAgIHsgcGF0aDogXCJcIiwgY29tcG9uZW50OiBMb2dpbkNvbXBvbmVudCAgfSxcbiAgICB7IHBhdGg6IFwiaXRlbXMvOmNpZGFkZS86dWYvOnRpcG9cIiwgY29tcG9uZW50OiBJdGVtc0NvbXBvbmVudCB9LFxuICAgIHsgcGF0aDogXCJlc3RpbG9zLzppZGNhdGVnb3JpYS86Y2lkYWRlLzp1Zi86dGlwb1wiLCBjb21wb25lbnQ6IEVzdGlsb3NFdnRDb21wb25lbnQgfSxcbiAgICB7IHBhdGg6IFwic3ViaXRlbS86aWRcIiwgY29tcG9uZW50OiBTdWJJdGVtRGV0YWlsQ29tcG9uZW50IH0sXG4gICAgeyBwYXRoOiBcIml0ZW0vOmlkXCIsIGNvbXBvbmVudDogSXRlbURldGFpbENvbXBvbmVudCB9LFxuICAgIHsgcGF0aDogXCJjZXAvOml0ZW1pZC86aWRjYXRlZ29yaWEvOmlkYWRtaW5cIiwgY29tcG9uZW50OiBDZXBDb21wb25lbnQgfSxcbiAgICB7IHBhdGg6IFwiZXZlbnRvcy86aXRlbWlkLzphY2FvLzppZGNhdGVnb3JpYS86aWRhZG1pblwiLCBjb21wb25lbnQ6IEV2ZW50b3NDb21wb25lbnQgfSxcbiAgICB7IHBhdGg6IFwiYnVzY2FjZXAvOml0ZW1pZC86aWRjYXRlZ29yaWEvOmlkYWRtaW5cIiwgY29tcG9uZW50OiBCdXNjYUNlcENvbXBvbmVudCB9LFxuICAgIHsgcGF0aDogXCJsb2NhaXMvOml0ZW1pZC86YWNhby86Y2VwLzpsb2dyYWRvdXJvLzpiYWlycm8vOmxvY2FsaWRhZGUvOnVmLzppZGNhdGVnb3JpYS86aWRhZG1pblwiLCBjb21wb25lbnQ6IExvY2Fpc0NvbXBvbmVudCB9LFxuXTtcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvclJvb3Qocm91dGVzKV0sXG4gICAgZXhwb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZV1cbn0pXG5leHBvcnQgY2xhc3MgQXBwUm91dGluZ01vZHVsZSB7IH1cbiJdfQ==