"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var http_client_1 = require("nativescript-angular/http-client");
var app_routing_module_1 = require("./app-routing.module");
var app_component_1 = require("./app.component");
var login_component_1 = require("./pages/login/login.component");
var estilosevt_component_1 = require("./pages/estilos/estilosevt.component");
var item_service_1 = require("./item/item.service");
var items_component_1 = require("./item/items.component");
var db_service_1 = require("./shared/db/db.service");
var user_1 = require("./shared/user/user");
var user_service_1 = require("./shared/user/user.service");
var location_service_1 = require("./shared/location/location.service");
var platform = require("platform");
var angular_1 = require("nativescript-ui-calendar/angular");
var forms_1 = require("nativescript-angular/forms");
var item_detail_component_1 = require("./item/item-detail.component");
var subitem_detail_component_1 = require("./item/subitem-detail.component");
var cep_1 = require("./item/cep");
var eventos_1 = require("./item/eventos");
var buscacep_1 = require("./item/buscacep");
var locais_1 = require("./item/locais");
if (platform.isIOS) {
    GMSServices.provideAPIKey("AIzaSyCpX-cfRtq9NrAeY1DRUs1uoLxeMwK_a4I");
}
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            bootstrap: [
                app_component_1.AppComponent
            ],
            imports: [
                nativescript_module_1.NativeScriptModule,
                app_routing_module_1.AppRoutingModule,
                http_client_1.NativeScriptHttpClientModule,
                angular_1.NativeScriptUICalendarModule,
                forms_1.NativeScriptFormsModule,
            ],
            declarations: [
                app_component_1.AppComponent,
                login_component_1.LoginComponent,
                item_detail_component_1.ItemDetailComponent,
                subitem_detail_component_1.SubItemDetailComponent,
                estilosevt_component_1.EstilosEvtComponent,
                items_component_1.ItemsComponent,
                cep_1.CepComponent,
                eventos_1.EventosComponent,
                buscacep_1.BuscaCepComponent,
                locais_1.LocaisComponent
            ],
            providers: [
                user_1.User,
                db_service_1.DbService,
                user_service_1.UserService,
                location_service_1.LocationService,
                item_service_1.ItemService,
                { provide: core_1.NgModuleFactoryLoader, useClass: core_1.SystemJsNgModuleLoader }
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwcC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMEc7QUFDMUcsZ0ZBQThFO0FBQzlFLGdFQUFnRjtBQUNoRiwyREFBd0Q7QUFDeEQsaURBQStDO0FBQy9DLGlFQUErRDtBQUMvRCw2RUFBMkU7QUFDM0Usb0RBQWtEO0FBQ2xELDBEQUF3RDtBQUN4RCxxREFBbUQ7QUFDbkQsMkNBQTBDO0FBQzFDLDJEQUF5RDtBQUN6RCx1RUFBcUU7QUFDckUsbUNBQXFDO0FBQ3JDLDREQUFnRjtBQUNoRixvREFBcUU7QUFDckUsc0VBQW1FO0FBQ25FLDRFQUF5RTtBQUN6RSxrQ0FBMEM7QUFDMUMsMENBQWtEO0FBQ2xELDRDQUFvRDtBQUNwRCx3Q0FBZ0Q7QUFJaEQsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDbkIsV0FBVyxDQUFDLGFBQWEsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUM7QUFzQ0Q7SUFBQTtJQUF5QixDQUFDO0lBQWIsU0FBUztRQW5DckIsZUFBUSxDQUFDO1lBQ04sU0FBUyxFQUFFO2dCQUNQLDRCQUFZO2FBQ2Y7WUFDRCxPQUFPLEVBQUU7Z0JBQ0wsd0NBQWtCO2dCQUNsQixxQ0FBZ0I7Z0JBQ2hCLDBDQUE0QjtnQkFDNUIsc0NBQTRCO2dCQUM1QiwrQkFBdUI7YUFDMUI7WUFDRCxZQUFZLEVBQUU7Z0JBQ1YsNEJBQVk7Z0JBQ1osZ0NBQWM7Z0JBQ2QsMkNBQW1CO2dCQUNuQixpREFBc0I7Z0JBQ3RCLDBDQUFtQjtnQkFDbkIsZ0NBQWM7Z0JBQ2Qsa0JBQVk7Z0JBQ1osMEJBQWdCO2dCQUNoQiw0QkFBaUI7Z0JBQ2pCLHdCQUFlO2FBQ2xCO1lBQ0QsU0FBUyxFQUFFO2dCQUNQLFdBQUk7Z0JBQ0osc0JBQVM7Z0JBQ1QsMEJBQVc7Z0JBQ1gsa0NBQWU7Z0JBQ2YsMEJBQVc7Z0JBQ1gsRUFBRSxPQUFPLEVBQUUsNEJBQXFCLEVBQUUsUUFBUSxFQUFFLDZCQUFzQixFQUFFO2FBQ3ZFO1lBQ0QsT0FBTyxFQUFFO2dCQUNMLHVCQUFnQjthQUNuQjtTQUNKLENBQUM7T0FDVyxTQUFTLENBQUk7SUFBRCxnQkFBQztDQUFBLEFBQTFCLElBQTBCO0FBQWIsOEJBQVMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTmdNb2R1bGVGYWN0b3J5TG9hZGVyLCBOT19FUlJPUlNfU0NIRU1BLCBTeXN0ZW1Kc05nTW9kdWxlTG9hZGVyIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdE1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9uYXRpdmVzY3JpcHQubW9kdWxlXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRIdHRwQ2xpZW50TW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2h0dHAtY2xpZW50XCI7XG5pbXBvcnQgeyBBcHBSb3V0aW5nTW9kdWxlIH0gZnJvbSBcIi4vYXBwLXJvdXRpbmcubW9kdWxlXCI7XG5pbXBvcnQgeyBBcHBDb21wb25lbnQgfSBmcm9tIFwiLi9hcHAuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBMb2dpbkNvbXBvbmVudCB9IGZyb20gXCIuL3BhZ2VzL2xvZ2luL2xvZ2luLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgRXN0aWxvc0V2dENvbXBvbmVudCB9IGZyb20gXCIuL3BhZ2VzL2VzdGlsb3MvZXN0aWxvc2V2dC5jb21wb25lbnRcIjtcbmltcG9ydCB7IEl0ZW1TZXJ2aWNlIH0gZnJvbSBcIi4vaXRlbS9pdGVtLnNlcnZpY2VcIjtcbmltcG9ydCB7IEl0ZW1zQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9pdGVtcy5jb21wb25lbnRcIjtcbmltcG9ydCB7IERiU2VydmljZSB9IGZyb20gXCIuL3NoYXJlZC9kYi9kYi5zZXJ2aWNlXCI7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4vc2hhcmVkL3VzZXIvdXNlclwiO1xuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tIFwiLi9zaGFyZWQvdXNlci91c2VyLnNlcnZpY2VcIjtcbmltcG9ydCB7IExvY2F0aW9uU2VydmljZSB9IGZyb20gXCIuL3NoYXJlZC9sb2NhdGlvbi9sb2NhdGlvbi5zZXJ2aWNlXCI7XG5pbXBvcnQgKiBhcyBwbGF0Zm9ybSBmcm9tIFwicGxhdGZvcm1cIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdFVJQ2FsZW5kYXJNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLWNhbGVuZGFyL2FuZ3VsYXJcIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2Zvcm1zXCI7XG5pbXBvcnQgeyBJdGVtRGV0YWlsQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9pdGVtLWRldGFpbC5jb21wb25lbnRcIjtcbmltcG9ydCB7IFN1Ykl0ZW1EZXRhaWxDb21wb25lbnQgfSBmcm9tIFwiLi9pdGVtL3N1Yml0ZW0tZGV0YWlsLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgQ2VwQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9jZXBcIjtcbmltcG9ydCB7IEV2ZW50b3NDb21wb25lbnQgfSBmcm9tIFwiLi9pdGVtL2V2ZW50b3NcIjtcbmltcG9ydCB7IEJ1c2NhQ2VwQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9idXNjYWNlcFwiO1xuaW1wb3J0IHsgTG9jYWlzQ29tcG9uZW50IH0gZnJvbSBcIi4vaXRlbS9sb2NhaXNcIjtcblxuZGVjbGFyZSB2YXIgR01TU2VydmljZXM6IGFueTtcblxuaWYgKHBsYXRmb3JtLmlzSU9TKSB7IFxuICBHTVNTZXJ2aWNlcy5wcm92aWRlQVBJS2V5KFwiQUl6YVN5Q3BYLWNmUnRxOU5yQWVZMURSVXMxdW9MeGVNd0tfYTRJXCIpO1xufVxuXG5cbkBOZ01vZHVsZSh7XG4gICAgYm9vdHN0cmFwOiBbXG4gICAgICAgIEFwcENvbXBvbmVudFxuICAgIF0sXG4gICAgaW1wb3J0czogW1xuICAgICAgICBOYXRpdmVTY3JpcHRNb2R1bGUsXG4gICAgICAgIEFwcFJvdXRpbmdNb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdEh0dHBDbGllbnRNb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdFVJQ2FsZW5kYXJNb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLFxuICAgIF0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIEFwcENvbXBvbmVudCxcbiAgICAgICAgTG9naW5Db21wb25lbnQsXG4gICAgICAgIEl0ZW1EZXRhaWxDb21wb25lbnQsXG4gICAgICAgIFN1Ykl0ZW1EZXRhaWxDb21wb25lbnQsXG4gICAgICAgIEVzdGlsb3NFdnRDb21wb25lbnQsXG4gICAgICAgIEl0ZW1zQ29tcG9uZW50LFxuICAgICAgICBDZXBDb21wb25lbnQsXG4gICAgICAgIEV2ZW50b3NDb21wb25lbnQsXG4gICAgICAgIEJ1c2NhQ2VwQ29tcG9uZW50LFxuICAgICAgICBMb2NhaXNDb21wb25lbnRcbiAgICBdLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBVc2VyLFxuICAgICAgICBEYlNlcnZpY2UsXG4gICAgICAgIFVzZXJTZXJ2aWNlLFxuICAgICAgICBMb2NhdGlvblNlcnZpY2UsXG4gICAgICAgIEl0ZW1TZXJ2aWNlLFxuICAgICAgICB7IHByb3ZpZGU6IE5nTW9kdWxlRmFjdG9yeUxvYWRlciwgdXNlQ2xhc3M6IFN5c3RlbUpzTmdNb2R1bGVMb2FkZXIgfVxuICAgIF0sXG4gICAgc2NoZW1hczogW1xuICAgICAgICBOT19FUlJPUlNfU0NIRU1BXG4gICAgXVxufSlcbmV4cG9ydCBjbGFzcyBBcHBNb2R1bGUgeyB9XG4iXX0=