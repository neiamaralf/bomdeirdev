"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var User = /** @class */ (function () {
    function User() {
        this.goodtoken = false;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUFBO1FBTUUsY0FBUyxHQUFDLEtBQUssQ0FBQztJQUNsQixDQUFDO0lBQUQsV0FBQztBQUFELENBQUMsQUFQRCxJQU9DO0FBUFksb0JBQUkiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgVXNlciB7XG4gIGVtYWlsOiBzdHJpbmc7XG4gIHNlbmhhPzogc3RyaW5nO1xuICBpZDpzdHJpbmc7XG4gIHRva2VuOnN0cmluZztcbiAgc3VwZXI6bnVtYmVyO1xuICBnb29kdG9rZW49ZmFsc2U7XG59XG4iXX0=