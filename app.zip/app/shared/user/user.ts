export class User {
  email: string;
  senha?: string;
  id:string;
  token:string;
  super:number;
  goodtoken=false;
}
