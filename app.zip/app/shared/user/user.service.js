"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var user_1 = require("./user");
var db_service_1 = require("../db/db.service");
var config_1 = require("../config");
var appsettings = require("application-settings");
var platformModule = require("tns-core-modules/platform");
var UserService = /** @class */ (function () {
    function UserService(user, db, routerExtensions) {
        this.user = user;
        this.db = db;
        this.routerExtensions = routerExtensions;
        user.goodtoken = false;
    }
    UserService.prototype.register = function (page) {
        return this.db.put({
            key: "adduser",
            email: this.user.email,
            password: this.user.senha,
            super: 1
        })
            .subscribe(function (res) {
            if (res.status == 'success') {
                config_1.Config.token = res.result.email;
                alert("Sua conta foi criada com sucesso.");
                page.toggleDisplay();
                console.dir(res);
                console.log(res.status);
            }
            else
                alert(res.msg);
        });
    };
    UserService.prototype.login = function (loginpage) {
        var _this = this;
        console.log("this.user");
        console.dir(this.user);
        return this.db.post({
            key: "login",
            email: loginpage.userService.user.email,
            password: loginpage.userService.user.senha,
            DeviceModel: platformModule.device.model,
            DeviceType: platformModule.device.deviceType,
            OS: platformModule.device.os,
            OSVersion: platformModule.device.osVersion,
            SDKVersion: platformModule.device.sdkVersion
        })
            .subscribe(function (res) {
            if (res.status == 'success') {
                config_1.Config.token = res.result.token;
                console.dir(res);
                _this.user = res.result;
                console.dir(_this.user);
                if (_this.user.id == undefined)
                    _this.user.super = 2;
                _this.saveusr();
                if (_this.user.super == 2)
                    _this.routerExtensions.navigate(["/items/0/0/onde"], { clearHistory: true });
                else
                    _this.routerExtensions.navigate(["/items/0/0/admin"], { clearHistory: true });
            }
            else
                alert(res.msg);
        });
    };
    UserService.prototype.saveusr = function () {
        appsettings.setString("usr", JSON.stringify(this.user));
    };
    UserService.prototype.logout = function () {
        var _this = this;
        this.db.post({ key: 'logout', id: this.user.id, token: this.user.token })
            .subscribe(function (res) {
            if (res.status == 'success') {
                appsettings.remove('usr');
                _this.user.goodtoken = false;
                _this.routerExtensions.navigate(["/"], { clearHistory: true });
            }
            else {
                alert(res.result.msg);
            }
        });
    };
    UserService.prototype.verifytoken = function (loginpage) {
        var _this = this;
        if (!appsettings.hasKey("usr"))
            return;
        var usr = JSON.parse(appsettings.getString("usr"));
        console.log("usr");
        console.dir(usr);
        this.user = usr;
        this.db.post({
            key: 'asserttoken',
            id: this.user.id,
            token: this.user.token
        })
            .subscribe(function (res) {
            if (res.status == 'success') {
                console.dir(res.result);
                _this.user.goodtoken = true;
                if (_this.user.super == 2)
                    _this.routerExtensions.navigate(["/items/0/0/onde"], { clearHistory: true });
                else
                    _this.routerExtensions.navigate(["/items/0/0/admin"], { clearHistory: true });
                console.dir(_this.user);
            }
            else {
                console.log("token inválido");
                // appsettings.remove("usr");
                _this.user.email = "";
                _this.user.senha = "";
                _this.routerExtensions.navigate(["/"]);
            }
        });
    };
    UserService.prototype.getCommonHeaders = function () {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        return headers;
    };
    UserService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [user_1.User, db_service_1.DbService, router_1.RouterExtensions])
    ], UserService);
    return UserService;
}());
exports.UserService = UserService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidXNlci5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTJDO0FBQzNDLHNEQUErRDtBQUMvRCwrQkFBOEI7QUFDOUIsK0NBQTZDO0FBQzdDLG9DQUFtQztBQUNuQyxrREFBb0Q7QUFDcEQsMERBQTREO0FBRzVEO0lBQ0UscUJBQW1CLElBQVUsRUFBUyxFQUFhLEVBQVUsZ0JBQWtDO1FBQTVFLFNBQUksR0FBSixJQUFJLENBQU07UUFBUyxPQUFFLEdBQUYsRUFBRSxDQUFXO1FBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtRQUM3RixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUN6QixDQUFDO0lBRUQsOEJBQVEsR0FBUixVQUFTLElBQUk7UUFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7WUFDakIsR0FBRyxFQUFFLFNBQVM7WUFDZCxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQ3RCLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUs7WUFDekIsS0FBSyxFQUFFLENBQUM7U0FDVCxDQUNBO2FBQ0UsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEVBQUUsQ0FBQyxDQUFPLEdBQUksQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDbkMsZUFBTSxDQUFDLEtBQUssR0FBUyxHQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDdkMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBTyxHQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakMsQ0FBQztZQUNELElBQUk7Z0JBQ0YsS0FBSyxDQUFPLEdBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCwyQkFBSyxHQUFMLFVBQU0sU0FBUztRQUFmLGlCQStCQztRQTlCQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ3RCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztZQUNsQixHQUFHLEVBQUUsT0FBTztZQUNaLEtBQUssRUFBRSxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQ3ZDLFFBQVEsRUFBRSxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQzFDLFdBQVcsRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUs7WUFDeEMsVUFBVSxFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUMsVUFBVTtZQUM1QyxFQUFFLEVBQUUsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzVCLFNBQVMsRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLFNBQVM7WUFDMUMsVUFBVSxFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUMsVUFBVTtTQUM3QyxDQUNBO2FBQ0UsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEVBQUUsQ0FBQyxDQUFPLEdBQUksQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDbkMsZUFBTSxDQUFDLEtBQUssR0FBUyxHQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQTtnQkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDakIsS0FBSSxDQUFDLElBQUksR0FBUyxHQUFJLENBQUMsTUFBTSxDQUFDO2dCQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkIsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksU0FBUyxDQUFDO29CQUM1QixLQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ3RCLEtBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDZixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUM7b0JBQ3ZCLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7Z0JBQzdFLElBQUk7b0JBQ0YsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUNoRixDQUFDO1lBQ0QsSUFBSTtnQkFDRixLQUFLLENBQU8sR0FBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDZCQUFPLEdBQVA7UUFDRSxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCw0QkFBTSxHQUFOO1FBQUEsaUJBV0M7UUFWQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3RFLFNBQVMsQ0FBQyxVQUFBLEdBQUc7WUFDWixFQUFFLENBQUMsQ0FBTyxHQUFJLENBQUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzFCLEtBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztnQkFDNUIsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDaEUsQ0FBQztZQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNOLEtBQUssQ0FBTyxHQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9CLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxpQ0FBVyxHQUFYLFVBQVksU0FBUztRQUFyQixpQkE4QkM7UUE3QkMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQUMsTUFBTSxDQUFDO1FBQ3ZDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxHQUFTLEdBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztZQUNYLEdBQUcsRUFBRSxhQUFhO1lBQ2xCLEVBQUUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDaEIsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztTQUN2QixDQUNBO2FBQ0UsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEVBQUUsQ0FBQyxDQUFPLEdBQUksQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDbkMsT0FBTyxDQUFDLEdBQUcsQ0FBTyxHQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9CLEtBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztnQkFDM0IsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO29CQUN2QixLQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO2dCQUM3RSxJQUFJO29CQUNGLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7Z0JBQzlFLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pCLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQy9CLDZCQUE2QjtnQkFDNUIsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2dCQUFBLEtBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDMUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDeEMsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQztJQUVELHNDQUFnQixHQUFoQjtRQUNFLElBQUksT0FBTyxHQUFHLElBQUksT0FBTyxFQUFFLENBQUM7UUFDNUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztRQUNuRCxNQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFoSFUsV0FBVztRQUR2QixpQkFBVSxFQUFFO3lDQUVjLFdBQUksRUFBYSxzQkFBUyxFQUE0Qix5QkFBZ0I7T0FEcEYsV0FBVyxDQW1IdkI7SUFBRCxrQkFBQztDQUFBLEFBbkhELElBbUhDO0FBbkhZLGtDQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBSb3V0ZXJFeHRlbnNpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgVXNlciB9IGZyb20gXCIuL3VzZXJcIjtcbmltcG9ydCB7IERiU2VydmljZSB9IGZyb20gXCIuLi9kYi9kYi5zZXJ2aWNlXCI7XG5pbXBvcnQgeyBDb25maWcgfSBmcm9tIFwiLi4vY29uZmlnXCI7XG5pbXBvcnQgKiBhcyBhcHBzZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCAqIGFzIHBsYXRmb3JtTW9kdWxlIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3BsYXRmb3JtXCI7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBVc2VyU2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyB1c2VyOiBVc2VyLCBwdWJsaWMgZGI6IERiU2VydmljZSwgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zKSB7XG4gICAgdXNlci5nb29kdG9rZW4gPSBmYWxzZTtcbiAgfVxuXG4gIHJlZ2lzdGVyKHBhZ2UpIHtcbiAgICByZXR1cm4gdGhpcy5kYi5wdXQoe1xuICAgICAga2V5OiBcImFkZHVzZXJcIixcbiAgICAgIGVtYWlsOiB0aGlzLnVzZXIuZW1haWwsXG4gICAgICBwYXNzd29yZDogdGhpcy51c2VyLnNlbmhhLFxuICAgICAgc3VwZXI6IDFcbiAgICB9XG4gICAgKVxuICAgICAgLnN1YnNjcmliZShyZXMgPT4ge1xuICAgICAgICBpZiAoKDxhbnk+cmVzKS5zdGF0dXMgPT0gJ3N1Y2Nlc3MnKSB7XG4gICAgICAgICAgQ29uZmlnLnRva2VuID0gKDxhbnk+cmVzKS5yZXN1bHQuZW1haWw7XG4gICAgICAgICAgYWxlcnQoXCJTdWEgY29udGEgZm9pIGNyaWFkYSBjb20gc3VjZXNzby5cIik7XG4gICAgICAgICAgcGFnZS50b2dnbGVEaXNwbGF5KCk7XG4gICAgICAgICAgY29uc29sZS5kaXIocmVzKTtcbiAgICAgICAgICBjb25zb2xlLmxvZygoPGFueT5yZXMpLnN0YXR1cyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZVxuICAgICAgICAgIGFsZXJ0KCg8YW55PnJlcykubXNnKVxuICAgICAgfSk7XG4gIH1cblxuICBsb2dpbihsb2dpbnBhZ2UpIHtcbiAgICBjb25zb2xlLmxvZyhcInRoaXMudXNlclwiKVxuICAgIGNvbnNvbGUuZGlyKHRoaXMudXNlcilcbiAgICByZXR1cm4gdGhpcy5kYi5wb3N0KHtcbiAgICAgIGtleTogXCJsb2dpblwiLFxuICAgICAgZW1haWw6IGxvZ2lucGFnZS51c2VyU2VydmljZS51c2VyLmVtYWlsLFxuICAgICAgcGFzc3dvcmQ6IGxvZ2lucGFnZS51c2VyU2VydmljZS51c2VyLnNlbmhhLFxuICAgICAgRGV2aWNlTW9kZWw6IHBsYXRmb3JtTW9kdWxlLmRldmljZS5tb2RlbCxcbiAgICAgIERldmljZVR5cGU6IHBsYXRmb3JtTW9kdWxlLmRldmljZS5kZXZpY2VUeXBlLFxuICAgICAgT1M6IHBsYXRmb3JtTW9kdWxlLmRldmljZS5vcyxcbiAgICAgIE9TVmVyc2lvbjogcGxhdGZvcm1Nb2R1bGUuZGV2aWNlLm9zVmVyc2lvbixcbiAgICAgIFNES1ZlcnNpb246IHBsYXRmb3JtTW9kdWxlLmRldmljZS5zZGtWZXJzaW9uXG4gICAgfVxuICAgIClcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgaWYgKCg8YW55PnJlcykuc3RhdHVzID09ICdzdWNjZXNzJykge1xuICAgICAgICAgIENvbmZpZy50b2tlbiA9ICg8YW55PnJlcykucmVzdWx0LnRva2VuXG4gICAgICAgICAgY29uc29sZS5kaXIocmVzKTtcbiAgICAgICAgICB0aGlzLnVzZXIgPSAoPGFueT5yZXMpLnJlc3VsdDtcbiAgICAgICAgICBjb25zb2xlLmRpcih0aGlzLnVzZXIpO1xuICAgICAgICAgIGlmICh0aGlzLnVzZXIuaWQgPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgdGhpcy51c2VyLnN1cGVyID0gMjtcbiAgICAgICAgICB0aGlzLnNhdmV1c3IoKTtcbiAgICAgICAgICBpZiAodGhpcy51c2VyLnN1cGVyID09IDIpXG4gICAgICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL2l0ZW1zLzAvMC9vbmRlXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvaXRlbXMvMC8wL2FkbWluXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KVxuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAgICBhbGVydCgoPGFueT5yZXMpLm1zZyk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHNhdmV1c3IoKSB7XG4gICAgYXBwc2V0dGluZ3Muc2V0U3RyaW5nKFwidXNyXCIsIEpTT04uc3RyaW5naWZ5KHRoaXMudXNlcikpO1xuICB9XG5cbiAgbG9nb3V0KCkge1xuICAgIHRoaXMuZGIucG9zdCh7IGtleTogJ2xvZ291dCcsIGlkOiB0aGlzLnVzZXIuaWQsIHRva2VuOiB0aGlzLnVzZXIudG9rZW4gfSlcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgaWYgKCg8YW55PnJlcykuc3RhdHVzID09ICdzdWNjZXNzJykge1xuICAgICAgICAgIGFwcHNldHRpbmdzLnJlbW92ZSgndXNyJyk7XG4gICAgICAgICAgdGhpcy51c2VyLmdvb2R0b2tlbiA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBhbGVydCgoPGFueT5yZXMpLnJlc3VsdC5tc2cpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgfVxuXG4gIHZlcmlmeXRva2VuKGxvZ2lucGFnZSkge1xuICAgIGlmICghYXBwc2V0dGluZ3MuaGFzS2V5KFwidXNyXCIpKSByZXR1cm47XG4gICAgdmFyIHVzciA9IEpTT04ucGFyc2UoYXBwc2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNyXCIpKTtcbiAgICBjb25zb2xlLmxvZyhcInVzclwiKTtcbiAgICBjb25zb2xlLmRpcih1c3IpO1xuICAgIHRoaXMudXNlciA9ICg8YW55PnVzcik7XG4gICAgdGhpcy5kYi5wb3N0KHtcbiAgICAgIGtleTogJ2Fzc2VydHRva2VuJyxcbiAgICAgIGlkOiB0aGlzLnVzZXIuaWQsXG4gICAgICB0b2tlbjogdGhpcy51c2VyLnRva2VuXG4gICAgfVxuICAgIClcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgaWYgKCg8YW55PnJlcykuc3RhdHVzID09ICdzdWNjZXNzJykge1xuICAgICAgICAgIGNvbnNvbGUuZGlyKCg8YW55PnJlcykucmVzdWx0KTtcbiAgICAgICAgICB0aGlzLnVzZXIuZ29vZHRva2VuID0gdHJ1ZTtcbiAgICAgICAgICBpZiAodGhpcy51c2VyLnN1cGVyID09IDIpXG4gICAgICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL2l0ZW1zLzAvMC9vbmRlXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvaXRlbXMvMC8wL2FkbWluXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KVxuICAgICAgICAgIGNvbnNvbGUuZGlyKHRoaXMudXNlcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJ0b2tlbiBpbnbDoWxpZG9cIik7XG4gICAgICAgICAvLyBhcHBzZXR0aW5ncy5yZW1vdmUoXCJ1c3JcIik7XG4gICAgICAgICAgdGhpcy51c2VyLmVtYWlsID0gXCJcIjt0aGlzLnVzZXIuc2VuaGEgPSBcIlwiO1xuICAgICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvXCJdKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgfVxuXG4gIGdldENvbW1vbkhlYWRlcnMoKSB7XG4gICAgbGV0IGhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuICAgIGhlYWRlcnMuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICByZXR1cm4gaGVhZGVycztcbiAgfVxuXG5cbn1cbiJdfQ==