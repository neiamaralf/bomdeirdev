export class Config {
  static apiUrl = "https://www.athena3d.com.br/bomdeir/";
  static token = "";
}