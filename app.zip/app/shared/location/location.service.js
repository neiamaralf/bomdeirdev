"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var db_service_1 = require("../db/db.service");
var geolocation = require("nativescript-geolocation");
var enums_1 = require("ui/enums");
var nativescript_google_maps_sdk_1 = require("nativescript-google-maps-sdk");
var LocationService = /** @class */ (function () {
    function LocationService(db) {
        this.db = db;
        this.enableLocation();
    }
    LocationService.prototype.enableLocation = function () {
        geolocation.isEnabled().then(function (isEnabled) {
            if (!isEnabled) {
                geolocation.enableLocationRequest().then(function () {
                    this.getLocationOnce()
                        .then(function (location) {
                        console.dir(location);
                    });
                }, function (e) {
                    console.log("Error: " + (e.message || e));
                });
            }
        }, function (e) {
            console.log("Error: " + (e.message || e));
        });
    };
    LocationService.prototype.getEndFromlatlong = function (retobj, callback) {
        var _this = this;
        this.getLocationOnce()
            .then(function (location) {
            console.log("Location received: ");
            var url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=";
            url = url + location.latitude.toString() + "," + location.longitude.toString();
            url = url + "&result_type=administrative_area_level_1|administrative_area_level_2&key=AIzaSyBjF_58qpK1CsH2SMZdhNtFmab87Q4wfWU";
            console.log(url);
            _this.db.geturl(url, "application/json").subscribe(function (res) {
                console.log("res localizacao:");
                console.dir(res);
                callback(res);
                //console.dir(retobj);
            });
        }).catch(function (error) {
            console.log("Location error received: " + error);
            alert("Location error received: " + error);
        });
    };
    ;
    LocationService.prototype.getlatlongFromEnd = function (enddata) {
        var url = "https://maps.googleapis.com/maps/api/geocode/json?address=";
        var end = enddata.logradouro.split(" ");
        end.forEach(function (e) {
            url = url + e + "+";
        });
        url.replace(/.$/, ",");
        url = url + "+" + enddata.numero + "+-+";
        var bair = enddata.bairro.split(" ");
        bair.forEach(function (e) {
            url = url + e + "+";
        });
        url.replace(/.$/, ",");
        url = url + "+";
        var cid = enddata.localidade.split(" ");
        cid.forEach(function (e) {
            url = url + e + "+";
        });
        url.replace(/.$/, ",");
        url = url + "-+" + enddata.uf + ",+" + enddata.cep;
        url = url + "&key=AIzaSyBjF_58qpK1CsH2SMZdhNtFmab87Q4wfWU";
        return this.db.geturl(url, "application/json");
    };
    ;
    LocationService.prototype.getLocationOnce = function () {
        return geolocation.getCurrentLocation({
            desiredAccuracy: enums_1.Accuracy.high,
            updateDistance: 5,
            timeout: 5000
        });
    };
    ;
    LocationService.prototype.startwatch = function (__this, marker) {
        this.watchId = geolocation.watchLocation(function (loc) {
            if (loc) {
                marker = __this.mapView.findMarker(function (marker) {
                    return marker.userData.index === 1;
                });
                loc.altitude = 0;
                marker.position = nativescript_google_maps_sdk_1.Position.positionFromLatLng(loc.latitude, loc.longitude);
                marker.snippet = "distância = " + geolocation.distance(loc, __this.location).toFixed(0) + " metros";
                // console.log("Received location: " + loc.latitude);
                // console.log("Received longitude: " + loc.longitude);
                // console.dir(loc);
                marker.showInfoWindow();
            }
        }, function (e) {
            console.log("Error: " + e.message);
        }, { desiredAccuracy: enums_1.Accuracy.high, updateDistance: 3, minimumUpdateTime: 1000 * 3 });
    };
    ;
    LocationService.prototype.stopwath = function () {
        if (this.watchId)
            geolocation.clearWatch(this.watchId);
    };
    ;
    LocationService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [db_service_1.DbService])
    ], LocationService);
    return LocationService;
}());
exports.LocationService = LocationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYXRpb24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxvY2F0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMkM7QUFDM0MsK0NBQTZDO0FBQzdDLHNEQUF3RDtBQUN4RCxrQ0FBb0M7QUFDcEMsNkVBQWlGO0FBU2pGO0lBSUMseUJBQW9CLEVBQWE7UUFBYixPQUFFLEdBQUYsRUFBRSxDQUFXO1FBQ2hDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUV2QixDQUFDO0lBRUQsd0NBQWMsR0FBZDtRQUNDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxTQUFTO1lBQy9DLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDaEIsV0FBVyxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSSxDQUFDO29CQUN4QyxJQUFJLENBQUMsZUFBZSxFQUFFO3lCQUNwQixJQUFJLENBQUMsVUFBVSxRQUFRO3dCQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFBO29CQUN0QixDQUFDLENBQUMsQ0FBQTtnQkFDSixDQUFDLEVBQUUsVUFBVSxDQUFDO29CQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxDQUFDLENBQUMsQ0FBQztZQUNKLENBQUM7UUFDRixDQUFDLEVBQUUsVUFBVSxDQUFDO1lBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7SUFDSixDQUFDO0lBRUQsMkNBQWlCLEdBQWpCLFVBQWtCLE1BQU0sRUFBQyxRQUFRO1FBQ2hDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsZUFBZSxFQUFFO2FBQ2pCLElBQUksQ0FBQyxVQUFVLFFBQVE7WUFDeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBQ25DLElBQUksR0FBRyxHQUFHLDJEQUEyRCxDQUFDO1lBQ3RFLEdBQUcsR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUMvRSxHQUFHLEdBQUcsR0FBRyxHQUFHLGtIQUFrSCxDQUFDO1lBQy9ILE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRztnQkFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO2dCQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFFYixzQkFBc0I7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLO1lBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxDQUFDLENBQUM7WUFDakQsS0FBSyxDQUFDLDJCQUEyQixHQUFHLEtBQUssQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUFBLENBQUM7SUFFRiwyQ0FBaUIsR0FBakIsVUFBa0IsT0FBTztRQUN2QixJQUFJLEdBQUcsR0FBRyw0REFBNEQsQ0FBQztRQUN2RSxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztZQUNuQixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QixHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUN6QyxJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNyQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztZQUNwQixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QixHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNoQixJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztZQUNuQixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QixHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQ25ELEdBQUcsR0FBRyxHQUFHLEdBQUcsOENBQThDLENBQUM7UUFDM0QsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFBQSxDQUFDO0lBRUYseUNBQWUsR0FBZjtRQUNFLE1BQU0sQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUM7WUFDbEMsZUFBZSxFQUFFLGdCQUFRLENBQUMsSUFBSTtZQUM5QixjQUFjLEVBQUUsQ0FBQztZQUNqQixPQUFPLEVBQUUsSUFBSTtTQUNoQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBQUEsQ0FBQztJQUVGLG9DQUFVLEdBQVYsVUFBVyxNQUFNLEVBQUUsTUFBTTtRQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsVUFBVSxHQUFHO1lBQ2xELEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ04sTUFBTSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLFVBQVUsTUFBTTtvQkFDL0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQztnQkFDdkMsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsR0FBRyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7Z0JBQ2pCLE1BQU0sQ0FBQyxRQUFRLEdBQUcsdUNBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDM0UsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLEdBQUcsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQ3BHLHFEQUFxRDtnQkFDckQsdURBQXVEO2dCQUN2RCxvQkFBb0I7Z0JBQ3BCLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM1QixDQUFDO1FBQ0wsQ0FBQyxFQUFFLFVBQVUsQ0FBQztZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN2QyxDQUFDLEVBQUUsRUFBRSxlQUFlLEVBQUUsZ0JBQVEsQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMzRixDQUFDO0lBQUEsQ0FBQztJQUVGLGtDQUFRLEdBQVI7UUFDSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQ2pCLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFBQSxDQUFDO0lBdEdXLGVBQWU7UUFEM0IsaUJBQVUsRUFBRTt5Q0FLWSxzQkFBUztPQUpyQixlQUFlLENBdUczQjtJQUFELHNCQUFDO0NBQUEsQUF2R0QsSUF1R0M7QUF2R1ksMENBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IERiU2VydmljZSB9IGZyb20gXCIuLi9kYi9kYi5zZXJ2aWNlXCI7XG5pbXBvcnQgKiBhcyBnZW9sb2NhdGlvbiBmcm9tIFwibmF0aXZlc2NyaXB0LWdlb2xvY2F0aW9uXCI7XG5pbXBvcnQgeyBBY2N1cmFjeSB9IGZyb20gXCJ1aS9lbnVtc1wiO1xuaW1wb3J0IHsgTWFwVmlldywgTWFya2VyLCBQb3NpdGlvbiwgQm91bmRzIH0gZnJvbSAnbmF0aXZlc2NyaXB0LWdvb2dsZS1tYXBzLXNkayc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9jYXRpb25EYXRhIHtcbiAgICBsYXRpdHVkZT86IG51bWJlcjtcbiAgICBsb25naXR1ZGU/OiBudW1iZXI7XG4gICAgYWx0aXR1ZGU/OiBudW1iZXI7XG59XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBMb2NhdGlvblNlcnZpY2UgeyBcbiAgICBcbiAgd2F0Y2hJZDogYW55O1xuXG4gY29uc3RydWN0b3IocHJpdmF0ZSBkYjogRGJTZXJ2aWNlKSB7XG4gIHRoaXMuZW5hYmxlTG9jYXRpb24oKTtcblxuIH1cblxuIGVuYWJsZUxvY2F0aW9uKCkge1xuICBnZW9sb2NhdGlvbi5pc0VuYWJsZWQoKS50aGVuKGZ1bmN0aW9uIChpc0VuYWJsZWQpIHtcbiAgIGlmICghaXNFbmFibGVkKSB7XG4gICAgZ2VvbG9jYXRpb24uZW5hYmxlTG9jYXRpb25SZXF1ZXN0KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgIHRoaXMuZ2V0TG9jYXRpb25PbmNlKClcbiAgICAgIC50aGVuKGZ1bmN0aW9uIChsb2NhdGlvbikge1xuICAgICAgIGNvbnNvbGUuZGlyKGxvY2F0aW9uKVxuICAgICAgfSlcbiAgICB9LCBmdW5jdGlvbiAoZSkge1xuICAgICBjb25zb2xlLmxvZyhcIkVycm9yOiBcIiArIChlLm1lc3NhZ2UgfHwgZSkpO1xuICAgIH0pO1xuICAgfVxuICB9LCBmdW5jdGlvbiAoZSkge1xuICAgY29uc29sZS5sb2coXCJFcnJvcjogXCIgKyAoZS5tZXNzYWdlIHx8IGUpKTtcbiAgfSk7XG4gfVxuXG4gZ2V0RW5kRnJvbWxhdGxvbmcocmV0b2JqLGNhbGxiYWNrKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG4gIHRoaXMuZ2V0TG9jYXRpb25PbmNlKClcbiAgICAgIC50aGVuKGZ1bmN0aW9uIChsb2NhdGlvbikge1xuICAgICAgY29uc29sZS5sb2coXCJMb2NhdGlvbiByZWNlaXZlZDogXCIpO1xuICAgICAgdmFyIHVybCA9IFwiaHR0cHM6Ly9tYXBzLmdvb2dsZWFwaXMuY29tL21hcHMvYXBpL2dlb2NvZGUvanNvbj9sYXRsbmc9XCI7XG4gICAgICB1cmwgPSB1cmwgKyBsb2NhdGlvbi5sYXRpdHVkZS50b1N0cmluZygpICsgXCIsXCIgKyBsb2NhdGlvbi5sb25naXR1ZGUudG9TdHJpbmcoKTtcbiAgICAgIHVybCA9IHVybCArIFwiJnJlc3VsdF90eXBlPWFkbWluaXN0cmF0aXZlX2FyZWFfbGV2ZWxfMXxhZG1pbmlzdHJhdGl2ZV9hcmVhX2xldmVsXzIma2V5PUFJemFTeUJqRl81OHFwSzFDc0gyU01aZGhOdEZtYWI4N1E0d2ZXVVwiO1xuICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgIF90aGlzLmRiLmdldHVybCh1cmwsIFwiYXBwbGljYXRpb24vanNvblwiKS5zdWJzY3JpYmUoZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBjb25zb2xlLmxvZyhcInJlcyBsb2NhbGl6YWNhbzpcIikgIFxuICAgICAgICBjb25zb2xlLmRpcihyZXMpO1xuICAgICAgICAgIGNhbGxiYWNrKHJlcylcbiAgICAgICAgIFxuICAgICAgICAgIC8vY29uc29sZS5kaXIocmV0b2JqKTtcbiAgICAgIH0pO1xuICB9KS5jYXRjaChmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiTG9jYXRpb24gZXJyb3IgcmVjZWl2ZWQ6IFwiICsgZXJyb3IpO1xuICAgICAgYWxlcnQoXCJMb2NhdGlvbiBlcnJvciByZWNlaXZlZDogXCIgKyBlcnJvcik7XG4gIH0pO1xufTtcblxuZ2V0bGF0bG9uZ0Zyb21FbmQoZW5kZGF0YSkge1xuICB2YXIgdXJsID0gXCJodHRwczovL21hcHMuZ29vZ2xlYXBpcy5jb20vbWFwcy9hcGkvZ2VvY29kZS9qc29uP2FkZHJlc3M9XCI7XG4gIHZhciBlbmQgPSBlbmRkYXRhLmxvZ3JhZG91cm8uc3BsaXQoXCIgXCIpO1xuICBlbmQuZm9yRWFjaChmdW5jdGlvbiAoZSkge1xuICAgICAgdXJsID0gdXJsICsgZSArIFwiK1wiO1xuICB9KTtcbiAgdXJsLnJlcGxhY2UoLy4kLywgXCIsXCIpO1xuICB1cmwgPSB1cmwgKyBcIitcIiArIGVuZGRhdGEubnVtZXJvICsgXCIrLStcIjtcbiAgdmFyIGJhaXIgPSBlbmRkYXRhLmJhaXJyby5zcGxpdChcIiBcIik7XG4gIGJhaXIuZm9yRWFjaChmdW5jdGlvbiAoZSkge1xuICAgICAgdXJsID0gdXJsICsgZSArIFwiK1wiO1xuICB9KTtcbiAgdXJsLnJlcGxhY2UoLy4kLywgXCIsXCIpO1xuICB1cmwgPSB1cmwgKyBcIitcIjtcbiAgdmFyIGNpZCA9IGVuZGRhdGEubG9jYWxpZGFkZS5zcGxpdChcIiBcIik7XG4gIGNpZC5mb3JFYWNoKGZ1bmN0aW9uIChlKSB7XG4gICAgICB1cmwgPSB1cmwgKyBlICsgXCIrXCI7XG4gIH0pO1xuICB1cmwucmVwbGFjZSgvLiQvLCBcIixcIik7XG4gIHVybCA9IHVybCArIFwiLStcIiArIGVuZGRhdGEudWYgKyBcIiwrXCIgKyBlbmRkYXRhLmNlcDtcbiAgdXJsID0gdXJsICsgXCIma2V5PUFJemFTeUJqRl81OHFwSzFDc0gyU01aZGhOdEZtYWI4N1E0d2ZXVVwiO1xuICByZXR1cm4gdGhpcy5kYi5nZXR1cmwodXJsLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG59O1xuXG5nZXRMb2NhdGlvbk9uY2UoKSB7XG4gIHJldHVybiBnZW9sb2NhdGlvbi5nZXRDdXJyZW50TG9jYXRpb24oe1xuICAgICAgZGVzaXJlZEFjY3VyYWN5OiBBY2N1cmFjeS5oaWdoLFxuICAgICAgdXBkYXRlRGlzdGFuY2U6IDUsXG4gICAgICB0aW1lb3V0OiA1MDAwXG4gIH0pO1xufTtcblxuc3RhcnR3YXRjaChfX3RoaXMsIG1hcmtlcikge1xuICAgIHRoaXMud2F0Y2hJZCA9IGdlb2xvY2F0aW9uLndhdGNoTG9jYXRpb24oZnVuY3Rpb24gKGxvYykge1xuICAgICAgICBpZiAobG9jKSB7XG4gICAgICAgICAgICBtYXJrZXIgPSBfX3RoaXMubWFwVmlldy5maW5kTWFya2VyKGZ1bmN0aW9uIChtYXJrZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbWFya2VyLnVzZXJEYXRhLmluZGV4ID09PSAxO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsb2MuYWx0aXR1ZGUgPSAwO1xuICAgICAgICAgICAgbWFya2VyLnBvc2l0aW9uID0gUG9zaXRpb24ucG9zaXRpb25Gcm9tTGF0TG5nKGxvYy5sYXRpdHVkZSwgbG9jLmxvbmdpdHVkZSk7XG4gICAgICAgICAgICBtYXJrZXIuc25pcHBldCA9IFwiZGlzdMOibmNpYSA9IFwiICsgZ2VvbG9jYXRpb24uZGlzdGFuY2UobG9jLCBfX3RoaXMubG9jYXRpb24pLnRvRml4ZWQoMCkgKyBcIiBtZXRyb3NcIjtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiUmVjZWl2ZWQgbG9jYXRpb246IFwiICsgbG9jLmxhdGl0dWRlKTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiUmVjZWl2ZWQgbG9uZ2l0dWRlOiBcIiArIGxvYy5sb25naXR1ZGUpO1xuICAgICAgICAgICAgLy8gY29uc29sZS5kaXIobG9jKTtcbiAgICAgICAgICAgIG1hcmtlci5zaG93SW5mb1dpbmRvdygpO1xuICAgICAgICB9XG4gICAgfSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvcjogXCIgKyBlLm1lc3NhZ2UpO1xuICAgIH0sIHsgZGVzaXJlZEFjY3VyYWN5OiBBY2N1cmFjeS5oaWdoLCB1cGRhdGVEaXN0YW5jZTogMywgbWluaW11bVVwZGF0ZVRpbWU6IDEwMDAgKiAzIH0pO1xufTtcblxuc3RvcHdhdGgoKSB7XG4gICAgaWYgKHRoaXMud2F0Y2hJZClcbiAgICBnZW9sb2NhdGlvbi5jbGVhcldhdGNoKHRoaXMud2F0Y2hJZCk7XG59O1xufSJdfQ==