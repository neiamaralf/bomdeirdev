"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var HTTP = require("@angular/common/http");
var config_1 = require("../config");
var DbService = /** @class */ (function () {
    function DbService(http) {
        this.http = http;
    }
    DbService.prototype.put = function (jsondata) {
        return this.http.put(config_1.Config.apiUrl + "put.php", { jsondata: jsondata }, { headers: this.getCommonHeaders("application/json") });
    };
    DbService.prototype.post = function (jsondata) {
        /*return fetch(Config.apiUrl + "post.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(jsondata)})*/
        return this.http.post(config_1.Config.apiUrl + "post.php", { jsondata: jsondata }, { headers: this.getCommonHeaders("application/json") });
    };
    DbService.prototype.delete = function (params) {
        return this.http.delete(config_1.Config.apiUrl + "delete.php?" + params, { headers: this.getCommonHeaders("application/json") });
    };
    DbService.prototype.get = function (params) {
        return this.http.get(config_1.Config.apiUrl + "get.php?" + params, { headers: this.getCommonHeaders("application/json") });
    };
    DbService.prototype.geturl = function (url, contenttype) {
        return this.http.get(encodeURI(url), { headers: this.getCommonHeaders(contenttype) });
    };
    DbService.prototype.getCommonHeaders = function (contenttype) {
        var headers = new HTTP.HttpHeaders();
        headers.append("Content-Type", contenttype);
        return headers;
    };
    DbService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [HTTP.HttpClient])
    ], DbService);
    return DbService;
}());
exports.DbService = DbService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGIuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRiLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMkM7QUFDM0MsMkNBQTZDO0FBQzdDLG9DQUFtQztBQUduQztJQUNFLG1CQUFvQixJQUFxQjtRQUFyQixTQUFJLEdBQUosSUFBSSxDQUFpQjtJQUV6QyxDQUFDO0lBRUQsdUJBQUcsR0FBSCxVQUFJLFFBQVE7UUFDVixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLEVBQUUsRUFBRSxRQUFRLFVBQUEsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUV2SCxDQUFDO0lBRUQsd0JBQUksR0FBSixVQUFLLFFBQVE7UUFDWDs7OzRDQUdvQztRQUNwQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBTSxDQUFDLE1BQU0sR0FBRyxVQUFVLEVBQUUsRUFBRSxRQUFRLFVBQUEsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUV6SCxDQUFDO0lBRUQsMEJBQU0sR0FBTixVQUFPLE1BQU07UUFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBTSxDQUFDLE1BQU0sR0FBRyxhQUFhLEdBQUcsTUFBTSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUV6SCxDQUFDO0lBR0QsdUJBQUcsR0FBSCxVQUFJLE1BQU07UUFFUixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBTSxDQUFDLE1BQU0sR0FBRyxVQUFVLEdBQUcsTUFBTSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNwSCxDQUFDO0lBRUQsMEJBQU0sR0FBTixVQUFPLEdBQUcsRUFBQyxXQUFXO1FBQ3BCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBRUQsb0NBQWdCLEdBQWhCLFVBQWlCLFdBQVc7UUFDMUIsSUFBSSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDckMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDNUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBdENVLFNBQVM7UUFEckIsaUJBQVUsRUFBRTt5Q0FFZSxJQUFJLENBQUMsVUFBVTtPQUQ5QixTQUFTLENBdUNyQjtJQUFELGdCQUFDO0NBQUEsQUF2Q0QsSUF1Q0M7QUF2Q1ksOEJBQVMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIEhUVFAgZnJvbSBcIkBhbmd1bGFyL2NvbW1vbi9odHRwXCI7XG5pbXBvcnQgeyBDb25maWcgfSBmcm9tIFwiLi4vY29uZmlnXCI7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBEYlNlcnZpY2Uge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEhUVFAuSHR0cENsaWVudCkge1xuXG4gIH1cblxuICBwdXQoanNvbmRhdGEpIHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnB1dChDb25maWcuYXBpVXJsICsgXCJwdXQucGhwXCIsIHsganNvbmRhdGEgfSwgeyBoZWFkZXJzOiB0aGlzLmdldENvbW1vbkhlYWRlcnMoXCJhcHBsaWNhdGlvbi9qc29uXCIpIH0pXG4gICAgIFxuICB9XG5cbiAgcG9zdChqc29uZGF0YSkge1xuICAgIC8qcmV0dXJuIGZldGNoKENvbmZpZy5hcGlVcmwgKyBcInBvc3QucGhwXCIsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShqc29uZGF0YSl9KSovXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KENvbmZpZy5hcGlVcmwgKyBcInBvc3QucGhwXCIsIHsganNvbmRhdGEgfSwgeyBoZWFkZXJzOiB0aGlzLmdldENvbW1vbkhlYWRlcnMoXCJhcHBsaWNhdGlvbi9qc29uXCIpIH0pXG4gICAgIFxuICB9XG5cbiAgZGVsZXRlKHBhcmFtcykge1xuICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlKENvbmZpZy5hcGlVcmwgKyBcImRlbGV0ZS5waHA/XCIgKyBwYXJhbXMsIHsgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKFwiYXBwbGljYXRpb24vanNvblwiKSB9KVxuICAgICAgXG4gIH1cblxuXG4gIGdldChwYXJhbXMpIHtcbiAgICBcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldChDb25maWcuYXBpVXJsICsgXCJnZXQucGhwP1wiICsgcGFyYW1zLCB7IGhlYWRlcnM6IHRoaXMuZ2V0Q29tbW9uSGVhZGVycyhcImFwcGxpY2F0aW9uL2pzb25cIikgfSk7XG4gIH1cblxuICBnZXR1cmwodXJsLGNvbnRlbnR0eXBlKSB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoZW5jb2RlVVJJKHVybCksIHsgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKGNvbnRlbnR0eXBlKSB9KTtcbiAgfVxuXG4gIGdldENvbW1vbkhlYWRlcnMoY29udGVudHR5cGUpIHtcbiAgICBsZXQgaGVhZGVycyA9IG5ldyBIVFRQLkh0dHBIZWFkZXJzKCk7XG4gICAgaGVhZGVycy5hcHBlbmQoXCJDb250ZW50LVR5cGVcIiwgY29udGVudHR5cGUpO1xuICAgIHJldHVybiBoZWFkZXJzO1xuICB9XG59XG4iXX0=