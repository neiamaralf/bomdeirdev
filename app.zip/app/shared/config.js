"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
    }
    Config.apiUrl = "https://www.athena3d.com.br/bomdeir/";
    Config.token = "";
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFBQTtJQUdBLENBQUM7SUFGUSxhQUFNLEdBQUcsc0NBQXNDLENBQUM7SUFDaEQsWUFBSyxHQUFHLEVBQUUsQ0FBQztJQUNwQixhQUFDO0NBQUEsQUFIRCxJQUdDO0FBSFksd0JBQU0iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgQ29uZmlnIHtcbiAgc3RhdGljIGFwaVVybCA9IFwiaHR0cHM6Ly93d3cuYXRoZW5hM2QuY29tLmJyL2JvbWRlaXIvXCI7XG4gIHN0YXRpYyB0b2tlbiA9IFwiXCI7XG59Il19