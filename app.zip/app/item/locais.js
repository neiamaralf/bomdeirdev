"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var observable_1 = require("data/observable");
var db_service_1 = require("../shared/db/db.service");
var item_service_1 = require("./item.service");
var page_1 = require("tns-core-modules/ui/page");
var router_2 = require("nativescript-angular/router");
var LocaisComponent = /** @class */ (function () {
    function LocaisComponent(routerExtensions, page, itemService, route, db) {
        this.routerExtensions = routerExtensions;
        this.page = page;
        this.itemService = itemService;
        this.route = route;
        this.db = db;
        this.dados = observable_1.fromObject({
            nome: "",
            numero: "",
            fone: '',
            email: '',
            site: '',
            acao: '',
            cep: '',
            logradouro: '',
            bairro: '',
            localidade: '',
            uf: '',
            idcategoria: '',
            idadmin: '',
            itemid: 0
        });
    }
    LocaisComponent.prototype.ngOnInit = function () {
        var itemid = this.route.snapshot.params["itemid"];
        this.dados.set("itemid", itemid);
        this.item = this.itemService.getItem(itemid);
        this.dados.set("acao", this.route.snapshot.params["acao"]);
        this.dados.set("cep", this.route.snapshot.params["cep"]);
        this.dados.set("logradouro", this.route.snapshot.params["logradouro"]);
        this.dados.set("bairro", this.route.snapshot.params["bairro"]);
        this.dados.set("localidade", this.route.snapshot.params["localidade"]);
        this.dados.set("uf", this.route.snapshot.params["uf"]);
        this.dados.set("idcategoria", this.route.snapshot.params["idcategoria"]);
        this.dados.set("idadmin", this.route.snapshot.params["idadmin"]);
        console.dir(this.dados);
        var txt = this.page.getViewById("nome");
        setTimeout(function () {
            txt.focus(); // Shows the soft input method, ususally a soft keyboard.
        }, 100);
    };
    LocaisComponent.prototype.save = function () {
        var _this = this;
        this.db
            .put({
            op: 'adicionar',
            key: 'locais',
            nome: this.dados.get("nome"),
            numero: this.dados.get("numero"),
            fone: this.dados.get("fone"),
            email: this.dados.get("email"),
            site: this.dados.get("site"),
            complemento: this.dados.get("complemento"),
            cep: this.dados.get("cep"),
            logradouro: this.dados.get("logradouro"),
            bairro: this.dados.get("bairro"),
            localidade: this.dados.get("localidade"),
            uf: this.dados.get("uf"),
            idcategoria: this.dados.get("idcategoria"),
            idadmin: this.dados.get("idadmin")
        })
            .subscribe(function (res) {
            _this.routerExtensions.backToPreviousPage();
            _this.routerExtensions.backToPreviousPage();
            _this.item.menu.push({
                key: res.key, name: res.result.nome, id: res.result.id, menu: null,
            });
            _this.item.menu.sort(function (a, b) {
                var nameA = a.name.toLowerCase(), nameB = b.name.toLowerCase();
                if (nameA < nameB)
                    return -1;
                if (nameA > nameB)
                    return 1;
                return 0;
            });
            console.dir(res);
            console.log(res.status);
        });
    };
    LocaisComponent = __decorate([
        core_1.Component({
            selector: "ns-locais",
            moduleId: module.id,
            templateUrl: "./locais.html",
        }),
        __metadata("design:paramtypes", [router_2.RouterExtensions,
            page_1.Page,
            item_service_1.ItemService,
            router_1.ActivatedRoute,
            db_service_1.DbService])
    ], LocaisComponent);
    return LocaisComponent;
}());
exports.LocaisComponent = LocaisComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWlzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibG9jYWlzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUFpRDtBQUNqRCw4Q0FBNkM7QUFDN0Msc0RBQW9EO0FBQ3BELCtDQUE2QztBQUc3QyxpREFBZ0Q7QUFDaEQsc0RBQStEO0FBTy9EO0lBb0JFLHlCQUNVLGdCQUFrQyxFQUNsQyxJQUFVLEVBQ1YsV0FBd0IsRUFDeEIsS0FBcUIsRUFDckIsRUFBYTtRQUpiLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsU0FBSSxHQUFKLElBQUksQ0FBTTtRQUNWLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQ3hCLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQ3JCLE9BQUUsR0FBRixFQUFFLENBQVc7UUF4QnZCLFVBQUssR0FBRyx1QkFBVSxDQUFDO1lBQ2pCLElBQUksRUFBRSxFQUFFO1lBQ1IsTUFBTSxFQUFFLEVBQUU7WUFDVixJQUFJLEVBQUUsRUFBRTtZQUNSLEtBQUssRUFBRSxFQUFFO1lBQ1QsSUFBSSxFQUFFLEVBQUU7WUFDUixJQUFJLEVBQUUsRUFBRTtZQUNSLEdBQUcsRUFBRSxFQUFFO1lBQ1AsVUFBVSxFQUFFLEVBQUU7WUFDZCxNQUFNLEVBQUUsRUFBRTtZQUNWLFVBQVUsRUFBRSxFQUFFO1lBQ2QsRUFBRSxFQUFFLEVBQUU7WUFDTixXQUFXLEVBQUUsRUFBRTtZQUNmLE9BQU8sRUFBRSxFQUFFO1lBQ1gsTUFBTSxFQUFFLENBQUM7U0FDVixDQUFDLENBQUM7SUFZSCxDQUFDO0lBRUQsa0NBQVEsR0FBUjtRQUNFLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDL0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7UUFDekUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQ2pFLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXhCLElBQUksR0FBRyxHQUF5QixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM5RCxVQUFVLENBQUM7WUFDVCxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyx5REFBeUQ7UUFDeEUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQztJQUVELDhCQUFJLEdBQUo7UUFBQSxpQkFxQ0M7UUFwQ0MsSUFBSSxDQUFDLEVBQUU7YUFDSixHQUFHLENBQUM7WUFDSCxFQUFFLEVBQUUsV0FBVztZQUNmLEdBQUcsRUFBRSxRQUFRO1lBQ2IsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztZQUM1QixNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1lBQ2hDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7WUFDNUIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztZQUM5QixJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1lBQzVCLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7WUFDMUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztZQUMxQixVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1lBQ3hDLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7WUFDaEMsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztZQUN4QyxFQUFFLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ3hCLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7WUFDMUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztTQUNuQyxDQUFDO2FBQ0QsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzNDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzNDLEtBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDbEIsR0FBRyxFQUFRLEdBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFRLEdBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBUSxHQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSTthQUN4RixDQUFDLENBQUM7WUFDSCxLQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztnQkFDaEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtnQkFDOUQsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztvQkFDaEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO2dCQUNYLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7b0JBQ2hCLE1BQU0sQ0FBQyxDQUFDLENBQUE7Z0JBQ1YsTUFBTSxDQUFDLENBQUMsQ0FBQTtZQUNWLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQixPQUFPLENBQUMsR0FBRyxDQUFPLEdBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqQyxDQUFDLENBQUMsQ0FBQztJQUVQLENBQUM7SUF2RlUsZUFBZTtRQUwzQixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSxlQUFlO1NBQzdCLENBQUM7eUNBc0I0Qix5QkFBZ0I7WUFDNUIsV0FBSTtZQUNHLDBCQUFXO1lBQ2pCLHVCQUFjO1lBQ2pCLHNCQUFTO09BekJaLGVBQWUsQ0F3RjNCO0lBQUQsc0JBQUM7Q0FBQSxBQXhGRCxJQXdGQztBQXhGWSwwQ0FBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgZnJvbU9iamVjdCB9IGZyb20gXCJkYXRhL29ic2VydmFibGVcIjtcbmltcG9ydCB7IERiU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvZGIvZGIuc2VydmljZVwiO1xuaW1wb3J0IHsgSXRlbVNlcnZpY2UgfSBmcm9tIFwiLi9pdGVtLnNlcnZpY2VcIjtcbmltcG9ydCB7IEl0ZW0gfSBmcm9tIFwiLi9pdGVtXCI7XG5pbXBvcnQgeyBUZXh0RmllbGQgfSBmcm9tIFwidWkvdGV4dC1maWVsZFwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3BhZ2VcIjtcbmltcG9ydCB7IFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogXCJucy1sb2NhaXNcIixcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgdGVtcGxhdGVVcmw6IFwiLi9sb2NhaXMuaHRtbFwiLFxufSlcbmV4cG9ydCBjbGFzcyBMb2NhaXNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBkYWRvcyA9IGZyb21PYmplY3Qoe1xuICAgIG5vbWU6IFwiXCIsXG4gICAgbnVtZXJvOiBcIlwiLFxuICAgIGZvbmU6ICcnLFxuICAgIGVtYWlsOiAnJyxcbiAgICBzaXRlOiAnJyxcbiAgICBhY2FvOiAnJyxcbiAgICBjZXA6ICcnLFxuICAgIGxvZ3JhZG91cm86ICcnLFxuICAgIGJhaXJybzogJycsXG4gICAgbG9jYWxpZGFkZTogJycsXG4gICAgdWY6ICcnLFxuICAgIGlkY2F0ZWdvcmlhOiAnJyxcbiAgICBpZGFkbWluOiAnJyxcbiAgICBpdGVtaWQ6IDBcbiAgfSk7XG5cbiAgaXRlbTogSXRlbTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlckV4dGVuc2lvbnM6IFJvdXRlckV4dGVuc2lvbnMsXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlLFxuICAgIHByaXZhdGUgaXRlbVNlcnZpY2U6IEl0ZW1TZXJ2aWNlLFxuICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgIHByaXZhdGUgZGI6IERiU2VydmljZVxuICApIHtcblxuICB9XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdmFyIGl0ZW1pZDogbnVtYmVyID0gdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpdGVtaWRcIl07XG4gICAgdGhpcy5kYWRvcy5zZXQoXCJpdGVtaWRcIiwgaXRlbWlkKTtcbiAgICB0aGlzLml0ZW0gPSB0aGlzLml0ZW1TZXJ2aWNlLmdldEl0ZW0oaXRlbWlkKTtcbiAgICB0aGlzLmRhZG9zLnNldChcImFjYW9cIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJhY2FvXCJdKTtcbiAgICB0aGlzLmRhZG9zLnNldChcImNlcFwiLCB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcImNlcFwiXSk7XG4gICAgdGhpcy5kYWRvcy5zZXQoXCJsb2dyYWRvdXJvXCIsIHRoaXMucm91dGUuc25hcHNob3QucGFyYW1zW1wibG9ncmFkb3Vyb1wiXSk7XG4gICAgdGhpcy5kYWRvcy5zZXQoXCJiYWlycm9cIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJiYWlycm9cIl0pO1xuICAgIHRoaXMuZGFkb3Muc2V0KFwibG9jYWxpZGFkZVwiLCB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcImxvY2FsaWRhZGVcIl0pO1xuICAgIHRoaXMuZGFkb3Muc2V0KFwidWZcIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJ1ZlwiXSk7XG4gICAgdGhpcy5kYWRvcy5zZXQoXCJpZGNhdGVnb3JpYVwiLCB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcImlkY2F0ZWdvcmlhXCJdKTtcbiAgICB0aGlzLmRhZG9zLnNldChcImlkYWRtaW5cIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpZGFkbWluXCJdKTtcbiAgICBjb25zb2xlLmRpcih0aGlzLmRhZG9zKTtcblxuICAgIHZhciB0eHQ6IFRleHRGaWVsZCA9IDxUZXh0RmllbGQ+dGhpcy5wYWdlLmdldFZpZXdCeUlkKFwibm9tZVwiKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHR4dC5mb2N1cygpOyAvLyBTaG93cyB0aGUgc29mdCBpbnB1dCBtZXRob2QsIHVzdXNhbGx5IGEgc29mdCBrZXlib2FyZC5cbiAgICB9LCAxMDApO1xuICB9XG5cbiAgc2F2ZSgpIHtcbiAgICB0aGlzLmRiXG4gICAgICAucHV0KHtcbiAgICAgICAgb3A6ICdhZGljaW9uYXInLFxuICAgICAgICBrZXk6ICdsb2NhaXMnLFxuICAgICAgICBub21lOiB0aGlzLmRhZG9zLmdldChcIm5vbWVcIiksXG4gICAgICAgIG51bWVybzogdGhpcy5kYWRvcy5nZXQoXCJudW1lcm9cIiksXG4gICAgICAgIGZvbmU6IHRoaXMuZGFkb3MuZ2V0KFwiZm9uZVwiKSxcbiAgICAgICAgZW1haWw6IHRoaXMuZGFkb3MuZ2V0KFwiZW1haWxcIiksXG4gICAgICAgIHNpdGU6IHRoaXMuZGFkb3MuZ2V0KFwic2l0ZVwiKSxcbiAgICAgICAgY29tcGxlbWVudG86IHRoaXMuZGFkb3MuZ2V0KFwiY29tcGxlbWVudG9cIiksXG4gICAgICAgIGNlcDogdGhpcy5kYWRvcy5nZXQoXCJjZXBcIiksXG4gICAgICAgIGxvZ3JhZG91cm86IHRoaXMuZGFkb3MuZ2V0KFwibG9ncmFkb3Vyb1wiKSxcbiAgICAgICAgYmFpcnJvOiB0aGlzLmRhZG9zLmdldChcImJhaXJyb1wiKSxcbiAgICAgICAgbG9jYWxpZGFkZTogdGhpcy5kYWRvcy5nZXQoXCJsb2NhbGlkYWRlXCIpLFxuICAgICAgICB1ZjogdGhpcy5kYWRvcy5nZXQoXCJ1ZlwiKSxcbiAgICAgICAgaWRjYXRlZ29yaWE6IHRoaXMuZGFkb3MuZ2V0KFwiaWRjYXRlZ29yaWFcIiksXG4gICAgICAgIGlkYWRtaW46IHRoaXMuZGFkb3MuZ2V0KFwiaWRhZG1pblwiKVxuICAgICAgfSlcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLmJhY2tUb1ByZXZpb3VzUGFnZSgpO1xuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMuYmFja1RvUHJldmlvdXNQYWdlKCk7XG4gICAgICAgIHRoaXMuaXRlbS5tZW51LnB1c2goe1xuICAgICAgICAgIGtleTogKDxhbnk+cmVzKS5rZXksIG5hbWU6ICg8YW55PnJlcykucmVzdWx0Lm5vbWUsIGlkOiAoPGFueT5yZXMpLnJlc3VsdC5pZCwgbWVudTogbnVsbCxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuaXRlbS5tZW51LnNvcnQoZnVuY3Rpb24gKGEsIGIpIHtcbiAgICAgICAgICB2YXIgbmFtZUEgPSBhLm5hbWUudG9Mb3dlckNhc2UoKSwgbmFtZUIgPSBiLm5hbWUudG9Mb3dlckNhc2UoKVxuICAgICAgICAgIGlmIChuYW1lQSA8IG5hbWVCKVxuICAgICAgICAgICAgcmV0dXJuIC0xXG4gICAgICAgICAgaWYgKG5hbWVBID4gbmFtZUIpXG4gICAgICAgICAgICByZXR1cm4gMVxuICAgICAgICAgIHJldHVybiAwXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zb2xlLmRpcihyZXMpO1xuICAgICAgICBjb25zb2xlLmxvZygoPGFueT5yZXMpLnN0YXR1cyk7XG4gICAgICB9KTtcblxuICB9XG59Il19