"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var db_service_1 = require("../shared/db/db.service");
var router_2 = require("@angular/router");
var observable_1 = require("data/observable");
var CepComponent = /** @class */ (function () {
    function CepComponent(routerExtensions, route, db) {
        this.routerExtensions = routerExtensions;
        this.route = route;
        this.db = db;
        this.params = observable_1.fromObject({
            itemid: 0,
            idcategoria: "",
            idadmin: ""
        });
        this.params.set("itemid", this.route.snapshot.params["itemid"]);
        this.params.set("idcategoria", this.route.snapshot.params["idcategoria"]);
        this.params.set("idadmin", this.route.snapshot.params["idadmin"]);
    }
    CepComponent.prototype.cepIsOk = function (cep) {
        return this.db
            .geturl("https://viacep.com.br/ws/" + cep + "/json/", "application/json");
    };
    CepComponent.prototype.continuar = function () {
        var _this = this;
        this.cepIsOk(this.cep)
            .subscribe(function (res) {
            console.dir(res);
            if (res.erro != true) {
                console.log("cep valido!");
                _this.routerExtensions.navigate(["/locais/" +
                        _this.params.get("itemid") + "/" +
                        "inserir/" +
                        res.cep + "/" +
                        res.logradouro + "/" +
                        res.bairro + "/" +
                        res.localidade + "/" +
                        res.uf + "/" +
                        _this.params.get("idcategoria") + "/" +
                        _this.params.get("idadmin")], {
                    clearHistory: false,
                });
            }
        }, function (error) {
            _this.onGetDataError(error);
        });
    };
    CepComponent.prototype.onGetDataError = function (error) {
        var body = error.json() || "";
        var err = body.error || JSON.stringify(body);
        console.log("onGetDataError: " + err);
    };
    CepComponent.prototype.buscacep = function () {
        this.routerExtensions.navigate(["/buscacep/" + this.params.get("itemid") + "/" + this.params.get("idcategoria") + "/" + this.params.get("idadmin")], { clearHistory: false });
    };
    CepComponent = __decorate([
        core_1.Component({
            selector: "ns-cep",
            moduleId: module.id,
            templateUrl: "./cep.html",
        }),
        __metadata("design:paramtypes", [router_1.RouterExtensions,
            router_2.ActivatedRoute,
            db_service_1.DbService])
    ], CepComponent);
    return CepComponent;
}());
exports.CepComponent = CepComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY2VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTBDO0FBQzFDLHNEQUErRDtBQUMvRCxzREFBb0Q7QUFDcEQsMENBQWlEO0FBQ2pELDhDQUE2QztBQU83QztJQVNFLHNCQUNVLGdCQUFrQyxFQUNsQyxLQUFxQixFQUNyQixFQUFhO1FBRmIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtRQUNsQyxVQUFLLEdBQUwsS0FBSyxDQUFnQjtRQUNyQixPQUFFLEdBQUYsRUFBRSxDQUFXO1FBVHZCLFdBQU0sR0FBRyx1QkFBVSxDQUFDO1lBQ2xCLE1BQU0sRUFBRSxDQUFDO1lBQ1QsV0FBVyxFQUFFLEVBQUU7WUFDZixPQUFPLEVBQUUsRUFBRTtTQUNaLENBQUMsQ0FBQztRQU1ELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7UUFDMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFRCw4QkFBTyxHQUFQLFVBQVEsR0FBRztRQUNULE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTthQUNYLE1BQU0sQ0FBQywyQkFBMkIsR0FBRyxHQUFHLEdBQUcsUUFBUSxFQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELGdDQUFTLEdBQVQ7UUFBQSxpQkE2QkM7UUE1QkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2FBQ25CLFNBQVMsQ0FBQyxVQUFBLEdBQUc7WUFDWixPQUFPLENBQUMsR0FBRyxDQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLEVBQUUsQ0FBQyxDQUFPLEdBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDM0IsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FDNUIsQ0FBQyxVQUFVO3dCQUNULEtBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUc7d0JBQy9CLFVBQVU7d0JBQ0osR0FBSSxDQUFDLEdBQUcsR0FBRyxHQUFHO3dCQUNkLEdBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRzt3QkFDckIsR0FBSSxDQUFDLE1BQU0sR0FBRyxHQUFHO3dCQUNqQixHQUFJLENBQUMsVUFBVSxHQUFHLEdBQUc7d0JBQ3JCLEdBQUksQ0FBQyxFQUFFLEdBQUcsR0FBRzt3QkFDbkIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRzt3QkFDcEMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFDN0I7b0JBQ0UsWUFBWSxFQUFFLEtBQUs7aUJBTXBCLENBQUMsQ0FBQztZQUNQLENBQUM7UUFDSCxDQUFDLEVBQUUsVUFBQyxLQUFLO1lBQ1AsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxxQ0FBYyxHQUF0QixVQUF1QixLQUFxQjtRQUMxQyxJQUFNLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ2hDLElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCwrQkFBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUNoTCxDQUFDO0lBOURVLFlBQVk7UUFMeEIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsWUFBWTtTQUMxQixDQUFDO3lDQVc0Qix5QkFBZ0I7WUFDM0IsdUJBQWM7WUFDakIsc0JBQVM7T0FaWixZQUFZLENBZ0V4QjtJQUFELG1CQUFDO0NBQUEsQUFoRUQsSUFnRUM7QUFoRVksb0NBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IERiU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvZGIvZGIuc2VydmljZVwiO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBmcm9tT2JqZWN0IH0gZnJvbSBcImRhdGEvb2JzZXJ2YWJsZVwiO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6IFwibnMtY2VwXCIsXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHRlbXBsYXRlVXJsOiBcIi4vY2VwLmh0bWxcIixcbn0pXG5leHBvcnQgY2xhc3MgQ2VwQ29tcG9uZW50IHtcbiAgY2VwOiBhbnk7XG5cbiAgcGFyYW1zID0gZnJvbU9iamVjdCh7XG4gICAgaXRlbWlkOiAwLFxuICAgIGlkY2F0ZWdvcmlhOiBcIlwiLFxuICAgIGlkYWRtaW46IFwiXCJcbiAgfSk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxuICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgIHByaXZhdGUgZGI6IERiU2VydmljZSkge1xuICAgIHRoaXMucGFyYW1zLnNldChcIml0ZW1pZFwiLCB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcIml0ZW1pZFwiXSk7XG4gICAgdGhpcy5wYXJhbXMuc2V0KFwiaWRjYXRlZ29yaWFcIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpZGNhdGVnb3JpYVwiXSk7XG4gICAgdGhpcy5wYXJhbXMuc2V0KFwiaWRhZG1pblwiLCB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtc1tcImlkYWRtaW5cIl0pO1xuICB9XG5cbiAgY2VwSXNPayhjZXApOiBhbnkge1xuICAgIHJldHVybiB0aGlzLmRiXG4gICAgICAuZ2V0dXJsKFwiaHR0cHM6Ly92aWFjZXAuY29tLmJyL3dzL1wiICsgY2VwICsgXCIvanNvbi9cIixcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gIH1cblxuICBjb250aW51YXIoKSB7XG4gICAgdGhpcy5jZXBJc09rKHRoaXMuY2VwKVxuICAgICAgLnN1YnNjcmliZShyZXMgPT4ge1xuICAgICAgICBjb25zb2xlLmRpcig8YW55PnJlcyk7XG4gICAgICAgIGlmICgoPGFueT5yZXMpLmVycm8gIT0gdHJ1ZSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2VwIHZhbGlkbyFcIik7XG4gICAgICAgICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLm5hdmlnYXRlKFxuICAgICAgICAgICAgW1wiL2xvY2Fpcy9cIiArXG4gICAgICAgICAgICAgIHRoaXMucGFyYW1zLmdldChcIml0ZW1pZFwiKSArIFwiL1wiICtcbiAgICAgICAgICAgICAgXCJpbnNlcmlyL1wiICtcbiAgICAgICAgICAgICAgKDxhbnk+cmVzKS5jZXAgKyBcIi9cIiArXG4gICAgICAgICAgICAgICg8YW55PnJlcykubG9ncmFkb3VybyArIFwiL1wiICtcbiAgICAgICAgICAgICAgKDxhbnk+cmVzKS5iYWlycm8gKyBcIi9cIiArXG4gICAgICAgICAgICAgICg8YW55PnJlcykubG9jYWxpZGFkZSArIFwiL1wiICtcbiAgICAgICAgICAgICAgKDxhbnk+cmVzKS51ZiArIFwiL1wiICtcbiAgICAgICAgICAgICAgdGhpcy5wYXJhbXMuZ2V0KFwiaWRjYXRlZ29yaWFcIikgKyBcIi9cIiArXG4gICAgICAgICAgICAgIHRoaXMucGFyYW1zLmdldChcImlkYWRtaW5cIildLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjbGVhckhpc3Rvcnk6IGZhbHNlLFxuICAgICAgICAgICAgIC8qIHRyYW5zaXRpb246IHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcImZsaXBcIixcbiAgICAgICAgICAgICAgICBkdXJhdGlvbjogMTAwMCxcbiAgICAgICAgICAgICAgICBjdXJ2ZTogXCJsaW5lYXJcIlxuICAgICAgICAgICAgICB9Ki9cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9LCAoZXJyb3IpID0+IHtcbiAgICAgICAgdGhpcy5vbkdldERhdGFFcnJvcihlcnJvcik7XG4gICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgb25HZXREYXRhRXJyb3IoZXJyb3I6IFJlc3BvbnNlIHwgYW55KSB7XG4gICAgY29uc3QgYm9keSA9IGVycm9yLmpzb24oKSB8fCBcIlwiO1xuICAgIGNvbnN0IGVyciA9IGJvZHkuZXJyb3IgfHwgSlNPTi5zdHJpbmdpZnkoYm9keSk7XG4gICAgY29uc29sZS5sb2coXCJvbkdldERhdGFFcnJvcjogXCIgKyBlcnIpO1xuICB9XG5cbiAgYnVzY2FjZXAoKSB7XG4gICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLm5hdmlnYXRlKFtcIi9idXNjYWNlcC9cIiArIHRoaXMucGFyYW1zLmdldChcIml0ZW1pZFwiKSArIFwiL1wiICsgdGhpcy5wYXJhbXMuZ2V0KFwiaWRjYXRlZ29yaWFcIikgKyBcIi9cIiArIHRoaXMucGFyYW1zLmdldChcImlkYWRtaW5cIildLCB7IGNsZWFySGlzdG9yeTogZmFsc2UgfSk7XG4gIH1cblxufVxuIl19