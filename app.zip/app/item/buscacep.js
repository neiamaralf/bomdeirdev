"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var db_service_1 = require("../shared/db/db.service");
var page_1 = require("tns-core-modules/ui/page");
var observable_1 = require("data/observable");
var router_2 = require("@angular/router");
var BuscaCepComponent = /** @class */ (function () {
    function BuscaCepComponent(routerExtensions, db, route, page) {
        this.routerExtensions = routerExtensions;
        this.db = db;
        this.route = route;
        this.page = page;
        this.isLoading = true;
        this.cepsearch = observable_1.fromObject({
            cidade: "",
            endereco: ""
        });
        this.params = observable_1.fromObject({
            itemid: 0,
            idcategoria: "",
            idadmin: ""
        });
        this.estadoss = [];
    }
    BuscaCepComponent.prototype.ngOnInit = function () {
        this.params.set("itemid", this.route.snapshot.params["itemid"]);
        this.params.set("idcategoria", this.route.snapshot.params["idcategoria"]);
        this.params.set("idadmin", this.route.snapshot.params["idadmin"]);
        this.listaUFs(this.estadoss);
        var txt = this.page.getViewById("endereco");
        setTimeout(function () {
            txt.focus(); // Shows the soft input method, ususally a soft keyboard.
        }, 100);
    };
    BuscaCepComponent.prototype.selectedIndexChanged = function (arg) {
        this.curestado = arg.object.items[arg.object.selectedIndex];
        console.dir(this.curestado);
    };
    BuscaCepComponent.prototype.listaUFs = function (array) {
        var _this = this;
        this.db
            .get("key=estados")
            .subscribe(function (res) {
            if (res != null) {
                res.result.forEach(function (row) {
                    var nome = row.nome;
                    array.push({
                        id: row.id,
                        nome: row.nome,
                        uf: row.uf,
                        toString: function () { return nome; },
                    });
                });
                var pickUF = _this.page.getViewById("lstpick");
                pickUF.items = array;
                pickUF.selectedIndex = 15;
                _this.curestado = pickUF.items[pickUF.selectedIndex];
                console.dir(array);
            }
            _this.isLoading = false;
        });
    };
    BuscaCepComponent.prototype.pesqCEP = function (UF, Cidade, Logradouro) {
        return this.db
            .geturl("https://viacep.com.br/ws/" + UF + "/" + Cidade + "/" + Logradouro + "/json/", "application/json");
    };
    BuscaCepComponent.prototype.buscacep = function () {
        var _this = this;
        console.dir(this.curestado);
        console.log(this.cepsearch.get("cidade"));
        console.log(this.cepsearch.get("endereco"));
        this.pesqCEP(this.curestado.uf, this.cepsearch.get("cidade"), this.cepsearch.get("endereco"))
            .subscribe(function (res) {
            console.dir(res);
            _this.cepres = res;
        });
    };
    BuscaCepComponent.prototype.onclick = function (item) {
        console.dir(item);
        this.routerExtensions.navigate(["/locais/" + this.params.get("itemid") + "/" + "inserir/" + item.cep + "/" + item.logradouro + "/" + item.bairro + "/" + item.localidade + "/" + item.uf + "/" + this.params.get("idcategoria") + "/" + this.params.get("idadmin")], { clearHistory: false });
    };
    BuscaCepComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: "./buscacep.html",
        }),
        __metadata("design:paramtypes", [router_1.RouterExtensions,
            db_service_1.DbService,
            router_2.ActivatedRoute,
            page_1.Page])
    ], BuscaCepComponent);
    return BuscaCepComponent;
}());
exports.BuscaCepComponent = BuscaCepComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVzY2FjZXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJidXNjYWNlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCxzREFBK0Q7QUFDL0Qsc0RBQW9EO0FBRXBELGlEQUFnRDtBQUNoRCw4Q0FBNkM7QUFFN0MsMENBQWlEO0FBTWpEO0lBaUJFLDJCQUNVLGdCQUFrQyxFQUNsQyxFQUFhLEVBQ2IsS0FBcUIsRUFDckIsSUFBVTtRQUhWLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsT0FBRSxHQUFGLEVBQUUsQ0FBVztRQUNiLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQ3JCLFNBQUksR0FBSixJQUFJLENBQU07UUFqQnBCLGNBQVMsR0FBWSxJQUFJLENBQUM7UUFFMUIsY0FBUyxHQUFHLHVCQUFVLENBQUM7WUFDckIsTUFBTSxFQUFFLEVBQUU7WUFDVixRQUFRLEVBQUUsRUFBRTtTQUNiLENBQUMsQ0FBQztRQUVILFdBQU0sR0FBRyx1QkFBVSxDQUFDO1lBQ2xCLE1BQU0sRUFBRSxDQUFDO1lBQ1QsV0FBVyxFQUFFLEVBQUU7WUFDZixPQUFPLEVBQUUsRUFBRTtTQUNaLENBQUMsQ0FBQztRQU9ELElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxvQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztRQUMxRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDN0IsSUFBSSxHQUFHLEdBQXlCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2xFLFVBQVUsQ0FBQztZQUNULEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLHlEQUF5RDtRQUN4RSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDVixDQUFDO0lBRUQsZ0RBQW9CLEdBQXBCLFVBQXFCLEdBQUc7UUFDdEIsSUFBSSxDQUFDLFNBQVMsR0FBUyxHQUFHLENBQUMsTUFBTyxDQUFDLEtBQUssQ0FBTyxHQUFHLENBQUMsTUFBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFRCxvQ0FBUSxHQUFSLFVBQVMsS0FBSztRQUFkLGlCQXNCQztRQXJCQyxJQUFJLENBQUMsRUFBRTthQUNKLEdBQUcsQ0FBQyxhQUFhLENBQUM7YUFDbEIsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNWLEdBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztvQkFDM0IsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQztvQkFDcEIsS0FBSyxDQUFDLElBQUksQ0FBQzt3QkFDVCxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUU7d0JBQ1YsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO3dCQUNkLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRTt3QkFDVixRQUFRLEVBQUUsY0FBUSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztxQkFDakMsQ0FBQyxDQUFBO2dCQUNKLENBQUMsQ0FBQyxDQUFDO2dCQUNILElBQUksTUFBTSxHQUEyQixLQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDdEUsTUFBTSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ3JCLE1BQU0sQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixLQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNwRCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JCLENBQUM7WUFDRCxLQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxtQ0FBTyxHQUFQLFVBQVEsRUFBRSxFQUFFLE1BQU0sRUFBRSxVQUFVO1FBQzVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTthQUNYLE1BQU0sQ0FBQywyQkFBMkIsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxHQUFHLEdBQUcsVUFBVSxHQUFHLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0lBQy9HLENBQUM7SUFFRCxvQ0FBUSxHQUFSO1FBQUEsaUJBVUM7UUFUQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDMUYsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNaLE9BQU8sQ0FBQyxHQUFHLENBQU0sR0FBRyxDQUFDLENBQUM7WUFDdEIsS0FBSSxDQUFDLE1BQU0sR0FBUSxHQUFHLENBQUM7UUFFekIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsbUNBQU8sR0FBUCxVQUFRLElBQUk7UUFDVixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBRWhTLENBQUM7SUF0RlUsaUJBQWlCO1FBSjdCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLGlCQUFpQjtTQUMvQixDQUFDO3lDQW1CNEIseUJBQWdCO1lBQzlCLHNCQUFTO1lBQ04sdUJBQWM7WUFDZixXQUFJO09BckJULGlCQUFpQixDQXdGN0I7SUFBRCx3QkFBQztDQUFBLEFBeEZELElBd0ZDO0FBeEZZLDhDQUFpQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBEYlNlcnZpY2UgfSBmcm9tIFwiLi4vc2hhcmVkL2RiL2RiLnNlcnZpY2VcIjtcbmltcG9ydCB7IExpc3RQaWNrZXIgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9saXN0LXBpY2tlclwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3BhZ2VcIjtcbmltcG9ydCB7IGZyb21PYmplY3QgfSBmcm9tIFwiZGF0YS9vYnNlcnZhYmxlXCI7XG5pbXBvcnQgeyBUZXh0RmllbGQgfSBmcm9tIFwidWkvdGV4dC1maWVsZFwiO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICB0ZW1wbGF0ZVVybDogXCIuL2J1c2NhY2VwLmh0bWxcIixcbn0pXG5leHBvcnQgY2xhc3MgQnVzY2FDZXBDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBjZXA6IGFueTtcbiAgcHVibGljIGVzdGFkb3NzOiBhbnlbXTtcbiAgY3VyZXN0YWRvOiBhbnk7XG4gIGlzTG9hZGluZzogYm9vbGVhbiA9IHRydWU7XG4gIGNlcHJlczogYW55O1xuICBjZXBzZWFyY2ggPSBmcm9tT2JqZWN0KHtcbiAgICBjaWRhZGU6IFwiXCIsXG4gICAgZW5kZXJlY286IFwiXCJcbiAgfSk7XG5cbiAgcGFyYW1zID0gZnJvbU9iamVjdCh7XG4gICAgaXRlbWlkOiAwLFxuICAgIGlkY2F0ZWdvcmlhOiBcIlwiLFxuICAgIGlkYWRtaW46IFwiXCJcbiAgfSk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxuICAgIHByaXZhdGUgZGI6IERiU2VydmljZSxcbiAgICBwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICBwcml2YXRlIHBhZ2U6IFBhZ2UpIHtcbiAgICB0aGlzLmVzdGFkb3NzID0gW107XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLnBhcmFtcy5zZXQoXCJpdGVtaWRcIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpdGVtaWRcIl0pO1xuICAgIHRoaXMucGFyYW1zLnNldChcImlkY2F0ZWdvcmlhXCIsIHRoaXMucm91dGUuc25hcHNob3QucGFyYW1zW1wiaWRjYXRlZ29yaWFcIl0pO1xuICAgIHRoaXMucGFyYW1zLnNldChcImlkYWRtaW5cIiwgdGhpcy5yb3V0ZS5zbmFwc2hvdC5wYXJhbXNbXCJpZGFkbWluXCJdKTtcbiAgICB0aGlzLmxpc3RhVUZzKHRoaXMuZXN0YWRvc3MpO1xuICAgIHZhciB0eHQ6IFRleHRGaWVsZCA9IDxUZXh0RmllbGQ+dGhpcy5wYWdlLmdldFZpZXdCeUlkKFwiZW5kZXJlY29cIik7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0eHQuZm9jdXMoKTsgLy8gU2hvd3MgdGhlIHNvZnQgaW5wdXQgbWV0aG9kLCB1c3VzYWxseSBhIHNvZnQga2V5Ym9hcmQuXG4gICAgfSwgMTAwKTtcbiAgfVxuXG4gIHNlbGVjdGVkSW5kZXhDaGFuZ2VkKGFyZykge1xuICAgIHRoaXMuY3VyZXN0YWRvID0gKDxhbnk+YXJnLm9iamVjdCkuaXRlbXNbKDxhbnk+YXJnLm9iamVjdCkuc2VsZWN0ZWRJbmRleF07XG4gICAgY29uc29sZS5kaXIodGhpcy5jdXJlc3RhZG8pO1xuICB9XG5cbiAgbGlzdGFVRnMoYXJyYXkpIHtcbiAgICB0aGlzLmRiXG4gICAgICAuZ2V0KFwia2V5PWVzdGFkb3NcIilcbiAgICAgIC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgaWYgKHJlcyAhPSBudWxsKSB7XG4gICAgICAgICAgKDxhbnk+cmVzKS5yZXN1bHQuZm9yRWFjaChyb3cgPT4ge1xuICAgICAgICAgICAgbGV0IG5vbWUgPSByb3cubm9tZTtcbiAgICAgICAgICAgIGFycmF5LnB1c2goe1xuICAgICAgICAgICAgICBpZDogcm93LmlkLFxuICAgICAgICAgICAgICBub21lOiByb3cubm9tZSxcbiAgICAgICAgICAgICAgdWY6IHJvdy51ZixcbiAgICAgICAgICAgICAgdG9TdHJpbmc6ICgpID0+IHsgcmV0dXJuIG5vbWU7IH0sXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHZhciBwaWNrVUY6IExpc3RQaWNrZXIgPSA8TGlzdFBpY2tlcj50aGlzLnBhZ2UuZ2V0Vmlld0J5SWQoXCJsc3RwaWNrXCIpO1xuICAgICAgICAgIHBpY2tVRi5pdGVtcyA9IGFycmF5O1xuICAgICAgICAgIHBpY2tVRi5zZWxlY3RlZEluZGV4ID0gMTU7XG4gICAgICAgICAgdGhpcy5jdXJlc3RhZG8gPSBwaWNrVUYuaXRlbXNbcGlja1VGLnNlbGVjdGVkSW5kZXhdO1xuICAgICAgICAgIGNvbnNvbGUuZGlyKGFycmF5KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgfSk7XG4gIH1cblxuICBwZXNxQ0VQKFVGLCBDaWRhZGUsIExvZ3JhZG91cm8pOiBhbnkge1xuICAgIHJldHVybiB0aGlzLmRiXG4gICAgICAuZ2V0dXJsKFwiaHR0cHM6Ly92aWFjZXAuY29tLmJyL3dzL1wiICsgVUYgKyBcIi9cIiArIENpZGFkZSArIFwiL1wiICsgTG9ncmFkb3VybyArIFwiL2pzb24vXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgfVxuXG4gIGJ1c2NhY2VwKCkge1xuICAgIGNvbnNvbGUuZGlyKHRoaXMuY3VyZXN0YWRvKTtcbiAgICBjb25zb2xlLmxvZyh0aGlzLmNlcHNlYXJjaC5nZXQoXCJjaWRhZGVcIikpO1xuICAgIGNvbnNvbGUubG9nKHRoaXMuY2Vwc2VhcmNoLmdldChcImVuZGVyZWNvXCIpKTtcbiAgICB0aGlzLnBlc3FDRVAodGhpcy5jdXJlc3RhZG8udWYsIHRoaXMuY2Vwc2VhcmNoLmdldChcImNpZGFkZVwiKSwgdGhpcy5jZXBzZWFyY2guZ2V0KFwiZW5kZXJlY29cIikpXG4gICAgICAuc3Vic2NyaWJlKHJlcyA9PiB7XG4gICAgICAgIGNvbnNvbGUuZGlyKDxhbnk+cmVzKTtcbiAgICAgICAgdGhpcy5jZXByZXMgPSA8YW55PnJlcztcblxuICAgICAgfSk7XG4gIH1cblxuICBvbmNsaWNrKGl0ZW0pIHtcbiAgICBjb25zb2xlLmRpcihpdGVtKTtcbiAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL2xvY2Fpcy9cIiArIHRoaXMucGFyYW1zLmdldChcIml0ZW1pZFwiKSArIFwiL1wiICsgXCJpbnNlcmlyL1wiICsgaXRlbS5jZXAgKyBcIi9cIiArIGl0ZW0ubG9ncmFkb3VybyArIFwiL1wiICsgaXRlbS5iYWlycm8gKyBcIi9cIiArIGl0ZW0ubG9jYWxpZGFkZSArIFwiL1wiICsgaXRlbS51ZiArIFwiL1wiICsgdGhpcy5wYXJhbXMuZ2V0KFwiaWRjYXRlZ29yaWFcIikgKyBcIi9cIiArIHRoaXMucGFyYW1zLmdldChcImlkYWRtaW5cIildLCB7IGNsZWFySGlzdG9yeTogZmFsc2UgfSk7XG5cbiAgfVxuXG59XG4iXX0=